import React from 'react';

interface BrandLogoProps {
  className?: string;
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-10 sm:h-12 w-auto'
}) => {
  return (
    <img
      src="/images/logo-empresasencarmen.svg"
      alt="Empresas en Carmen - Directorio Empresarial"
      className={`${className} object-contain select-none`}
      loading="eager"
      onError={(e) => {
        const target = e.target as HTMLImageElement;
        target.onerror = null;
        target.src = '/icons/icon-512.svg';
      }}
    />
  );
};
