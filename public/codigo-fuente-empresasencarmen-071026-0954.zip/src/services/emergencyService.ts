import DEFAULT_EMERGENCY_SERVICES from '../data/emergency_guide_carmen.json';

export interface EmergencyServiceItem {
  id: string;
  name: string;
  category: string;
  phone: string;
  whatsapp?: string;
  address: string;
  schedule: string;
  description: string;
  icon: string;
  badge: string;
  isUrgent?: boolean;
}

const STORAGE_KEY = 'carmen_emergency_services_v2';

export const getEmergencyServices = (): EmergencyServiceItem[] => {
  if (typeof window === 'undefined') return DEFAULT_EMERGENCY_SERVICES as EmergencyServiceItem[];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_EMERGENCY_SERVICES));
      return DEFAULT_EMERGENCY_SERVICES as EmergencyServiceItem[];
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
    return DEFAULT_EMERGENCY_SERVICES as EmergencyServiceItem[];
  } catch (e) {
    console.error('Error reading emergency services from localStorage:', e);
    return DEFAULT_EMERGENCY_SERVICES as EmergencyServiceItem[];
  }
};

export const saveEmergencyServices = (services: EmergencyServiceItem[]): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(services));
    window.dispatchEvent(new CustomEvent('emergency-guide-updated'));
  } catch (e) {
    console.error('Error saving emergency services to localStorage:', e);
  }
};

export const addEmergencyService = (item: Omit<EmergencyServiceItem, 'id'>): EmergencyServiceItem => {
  const current = getEmergencyServices();
  const newItem: EmergencyServiceItem = {
    ...item,
    id: 'em-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6)
  };
  const updated = [newItem, ...current];
  saveEmergencyServices(updated);
  return newItem;
};

export const updateEmergencyService = (id: string, updates: Partial<EmergencyServiceItem>): boolean => {
  const current = getEmergencyServices();
  const idx = current.findIndex(s => s.id === id);
  if (idx === -1) return false;
  current[idx] = { ...current[idx], ...updates };
  saveEmergencyServices(current);
  return true;
};

export const deleteEmergencyService = (id: string): boolean => {
  const current = getEmergencyServices();
  const filtered = current.filter(s => s.id !== id);
  if (filtered.length === current.length) return false;
  saveEmergencyServices(filtered);
  return true;
};

export const resetEmergencyServicesToDefault = (): EmergencyServiceItem[] => {
  if (typeof window !== 'undefined') {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(DEFAULT_EMERGENCY_SERVICES));
    window.dispatchEvent(new CustomEvent('emergency-guide-updated'));
  }
  return DEFAULT_EMERGENCY_SERVICES as EmergencyServiceItem[];
};
