import dotenv from 'dotenv';
dotenv.config({ override: true });
import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { initializeApp, getApps } from 'firebase/app';
import { getFirestore, collection, getDocs, doc, getDoc, setDoc, deleteDoc, updateDoc } from 'firebase/firestore';
import { ZipArchive } from 'archiver';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT || process.env.DEFAULT_APP_PORT) || 3000;

// 1. Bot & Scanner Protection Middleware (Block directory traversal, .env, wp-login, etc.)
app.use((req: Request, res: Response, next) => {
  const pathLower = (req.path || '').toLowerCase();
  
  if (
    pathLower.includes('.env') ||
    pathLower.includes('.git') ||
    pathLower.includes('..') ||
    pathLower.includes('wp-login') ||
    pathLower.includes('wp-admin') ||
    pathLower.includes('xmlrpc.php') ||
    pathLower.includes('eval-stdin') ||
    pathLower.includes('phpinfo') ||
    pathLower.includes('actuator') ||
    pathLower.includes('.aws')
  ) {
    return res.status(404).end();
  }

  next();
});

// 2. IP Rate Limiter to block automated bot floods (e.g. 10 million requests/day attack)
const ipRequestCounts = new Map<string, { count: number; resetAt: number }>();
setInterval(() => {
  const now = Date.now();
  for (const [ip, data] of ipRequestCounts.entries()) {
    if (now > data.resetAt) {
      ipRequestCounts.delete(ip);
    }
  }
}, 5 * 60 * 1000).unref();

app.use((req: Request, res: Response, next) => {
  const ip = (req.headers['x-forwarded-for'] as string)?.split(',')[0].trim() || req.ip || 'unknown';
  const now = Date.now();
  const windowMs = 60 * 1000;
  const maxRequestsPerMinute = 180;

  let entry = ipRequestCounts.get(ip);
  if (!entry || now > entry.resetAt) {
    entry = { count: 1, resetAt: now + windowMs };
    ipRequestCounts.set(ip, entry);
  } else {
    entry.count++;
  }

  if (entry.count > maxRequestsPerMinute) {
    return res.status(429).json({ error: 'Demasiadas solicitudes. Espere un momento.' });
  }

  next();
});

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Serve media assets directly with long-term caching (bypasses any Cloudflare /wp- blocks)
app.use('/media', express.static(path.resolve(__dirname, 'public/wp-content/uploads'), {
  maxAge: 30 * 24 * 60 * 60 * 1000,
  setHeaders: (res) => {
    res.setHeader('Cache-Control', 'public, max-age=2592000, immutable');
  }
}));

// Serve WordPress uploads directly from public if present, with caching
app.use('/wp-content', express.static(path.resolve(__dirname, 'public/wp-content'), {
  maxAge: 7 * 24 * 60 * 60 * 1000,
  setHeaders: (res) => {
    res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
  }
}));

// Fallback for missing wp-content/uploads when requested on non-production domains (e.g. dev/preview/Cloud Run)
app.get('/wp-content/uploads/*', (req: Request, res: Response) => {
  const host = (req.hostname || req.headers.host || '').toLowerCase();
  if (!host.includes('empresasencarmen.com')) {
    const subpath = req.params[0];
    return res.redirect(302, `https://empresasencarmen.com/wp-content/uploads/${subpath}`);
  }
  return res.status(404).send('Image not found');
});

// Fallback for legacy /media/* requests
app.get('/media/*', (req: Request, res: Response) => {
  const host = (req.hostname || req.headers.host || '').toLowerCase();
  const subpath = req.params[0];
  if (!host.includes('empresasencarmen.com')) {
    return res.redirect(302, `https://empresasencarmen.com/wp-content/uploads/${subpath}`);
  }
  return res.redirect(301, `/wp-content/uploads/${subpath}`);
});

// Initialize Firebase
let firestoreDb: any = null;
try {
  const firebaseConfigPath = path.resolve(__dirname, 'firebase-applet-config.json');
  if (fs.existsSync(firebaseConfigPath)) {
    const config = JSON.parse(fs.readFileSync(firebaseConfigPath, 'utf8'));
    const firebaseApp = getApps().length === 0 ? initializeApp(config) : getApps()[0];
    firestoreDb = getFirestore(firebaseApp, config.firestoreDatabaseId);
    console.log('[Firebase] Conectado a Firestore:', config.firestoreDatabaseId || 'default');
  }
} catch (e) {
  console.warn('[Firebase] No se pudo inicializar Firestore:', e);
}

// Memory caches
let businessesCache: any[] = [];
let categoriesCache: any[] = [];
let eventsCache: any[] = [];
let promotionsCache: any[] = [];
let reportsCache: any[] = [];
let claimedCouponsCache: any[] = [];
let editPinsCache: Record<number, { pin: string; expiresAt: number; remainingMinutes: number }> = {};

// Load Seed Businesses
try {
  const bizPath = path.resolve(__dirname, 'src/data/businesses_seed.json');
  if (fs.existsSync(bizPath)) {
    businessesCache = JSON.parse(fs.readFileSync(bizPath, 'utf8'));
    console.log(`[Cache] ${businessesCache.length} empresas cargadas de seed.`);
  }
} catch (e) {
  console.warn('[Cache] Error cargando businesses_seed:', e);
}

// Load Seed Categories
try {
  const catPath = path.resolve(__dirname, 'src/data/categories_seed.json');
  if (fs.existsSync(catPath)) {
    categoriesCache = JSON.parse(fs.readFileSync(catPath, 'utf8'));
    console.log(`[Cache] ${categoriesCache.length} categorías cargadas de seed.`);
  }
} catch (e) {
  console.warn('[Cache] Error cargando categories_seed:', e);
}

// Thematic representative images for events in Ciudad del Carmen
const THEMATIC_EVENT_IMAGES_SERVER = {
  running: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=800&auto=format&fit=crop&q=80',
  cycling: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182?w=800&auto=format&fit=crop&q=80',
  soccer: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&auto=format&fit=crop&q=80',
  baseball: 'https://images.unsplash.com/photo-1508344928928-7165b67de128?w=800&auto=format&fit=crop&q=80',
  fishing: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&auto=format&fit=crop&q=80',
  sportsGeneral: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
  conference: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&auto=format&fit=crop&q=80',
  agriculture: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800&auto=format&fit=crop&q=80',
  concert: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80',
  partyNight: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80',
  tradicionZaragoza: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80',
  bazar: 'https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=800&auto=format&fit=crop&q=80',
  gastronomiaMariscos: 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=800&auto=format&fit=crop&q=80',
  grill: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop&q=80',
  bakeryCafe: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&auto=format&fit=crop&q=80',
  diaDeMuertos: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80',
  theater: 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=800&auto=format&fit=crop&q=80',
  dance: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&auto=format&fit=crop&q=80',
  cinema: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&auto=format&fit=crop&q=80',
  artExhibition: 'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?w=800&auto=format&fit=crop&q=80',
  kidsFamily: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=800&auto=format&fit=crop&q=80',
  pets: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800&auto=format&fit=crop&q=80',
  beach: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
  patronalFiesta: 'https://images.unsplash.com/photo-1518638150340-f706e86654de?w=800&auto=format&fit=crop&q=80',
  wellness: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=800&auto=format&fit=crop&q=80'
};

// Smart representative image resolver for events in Ciudad del Carmen
function getEventRepresentativeImageServer(event: {
  title?: string;
  category?: string;
  categorySlug?: string;
  description?: string;
  location?: string;
  image?: string;
}): string {
  // If image is already an absolute HTTP/HTTPS URL, preserve it
  if (event.image && typeof event.image === 'string' && event.image.startsWith('http')) {
    return event.image.trim();
  }

  // If image is a legacy relative upload, map known placeholders to permanent HTTPS URLs
  if (event.image && typeof event.image === 'string') {
    const raw = event.image.trim();
    if (raw.includes('dia-de-muertos')) return THEMATIC_EVENT_IMAGES_SERVER.diaDeMuertos;
    if (raw.includes('kiosco-parque-zaragoza')) return THEMATIC_EVENT_IMAGES_SERVER.tradicionZaragoza;
    if (raw.includes('bazar-emprendedores')) return THEMATIC_EVENT_IMAGES_SERVER.bazar;
    if (raw.includes('festival-gastronomico')) return THEMATIC_EVENT_IMAGES_SERVER.gastronomiaMariscos;
    if (raw.includes('concierto-musica')) return THEMATIC_EVENT_IMAGES_SERVER.concert;
  }

  const text = `${event.title || ''} ${event.description || ''} ${event.category || ''} ${event.location || ''}`.toLowerCase();

  // 1. Día de Muertos / Tradiciones de Muertos / Catrinas / Hanal Pixán
  if (
    text.includes('muerto') ||
    text.includes('catrina') ||
    text.includes('cempasúchil') ||
    text.includes('cempasuchil') ||
    text.includes('ánima') ||
    text.includes('anima') ||
    text.includes('altar') ||
    text.includes('calaver') ||
    text.includes('hanal pix') ||
    text.includes('hallow')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.diaDeMuertos;
  }

  // 2. Agroindustria / Congreso Agroindustrial / Campo / Productos de Campeche
  if (
    text.includes('agroindustrial') ||
    text.includes('agro') ||
    text.includes('agrícol') ||
    text.includes('agricol') ||
    text.includes('campo') ||
    text.includes('siembra') ||
    text.includes('ganader') ||
    text.includes('cosecha') ||
    text.includes('productos de campeche')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.agriculture;
  }

  // 3. Carreras, Maratones, 5K, 10K, Atletismo, Octubre Rosa
  if (
    text.includes('carrera') ||
    text.includes('maratón') ||
    text.includes('maraton') ||
    text.includes('5k') ||
    text.includes('10k') ||
    text.includes('21k') ||
    text.includes('atlet') ||
    text.includes('corredor') ||
    text.includes('running') ||
    text.includes('octubre rosa') ||
    text.includes('cáncer de mama')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.running;
  }

  // 4. Ciclismo / Rodadas / Bicicleta
  if (
    text.includes('rodada') ||
    text.includes('ciclis') ||
    text.includes('bicicleta') ||
    text.includes('bici')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.cycling;
  }

  // 5. Pesca / Torneo de Pesca / Sábalo / Marítimo
  if (
    text.includes('pesca') ||
    text.includes('sábalo') ||
    text.includes('sabalo') ||
    text.includes('anzuelo') ||
    text.includes('lancha')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.fishing;
  }

  // 6. Fútbol / Soccer
  if (
    text.includes('fútbol') ||
    text.includes('futbol') ||
    text.includes('soccer') ||
    text.includes('gol')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.soccer;
  }

  // 7. Béisbol / Softbol
  if (
    text.includes('béisbol') ||
    text.includes('beisbol') ||
    text.includes('softbol') ||
    text.includes('pelota') ||
    text.includes('jonrón') ||
    text.includes('resineros')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.baseball;
  }

  // 8. Congresos / Convenciones / Carmen XXI / Foros / Cumbres / Negocios / Simposio
  if (
    text.includes('congreso') ||
    text.includes('convención') ||
    text.includes('convencion') ||
    text.includes('carmen xxi') ||
    text.includes('foro') ||
    text.includes('cumbre') ||
    text.includes('simposio') ||
    text.includes('conferencia') ||
    text.includes('panel') ||
    text.includes('empresarial') ||
    text.includes('negocios')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.conference;
  }

  // 9. Teatro / Artes Escénicas / Monólogo / Stand Up / Comedia
  if (
    text.includes('teatro') ||
    text.includes('obra') ||
    text.includes('monólogo') ||
    text.includes('monologo') ||
    text.includes('stand up') ||
    text.includes('comedia') ||
    text.includes('dramat') ||
    text.includes('escena') ||
    text.includes('teatro carmelita')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.theater;
  }

  // 10. Danza / Baile / Folclor / Ballet / Jarana
  if (
    text.includes('danza') ||
    text.includes('baile') ||
    text.includes('ballet') ||
    text.includes('folclor') ||
    text.includes('jarana') ||
    text.includes('coreograf')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.dance;
  }

  // 11. Cine / Películas / Proyección al aire libre
  if (
    text.includes('cine') ||
    text.includes('película') ||
    text.includes('pelicula') ||
    text.includes('cortometraje') ||
    text.includes('film') ||
    text.includes('proyección') ||
    text.includes('proyeccion')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.cinema;
  }

  // 12. Arte / Pintura / Galerías / Exposiciones Plásticas
  if (
    text.includes('exposición') ||
    text.includes('exposicion') ||
    text.includes('galería') ||
    text.includes('galeria') ||
    text.includes('pintura') ||
    text.includes('escultura') ||
    text.includes('fotografía') ||
    text.includes('fotografia') ||
    text.includes('artes plásticas')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.artExhibition;
  }

  // 13. Kiosco Zaragoza / Danzón / Marimba / Boleros / Tradición Carmelita
  if (
    text.includes('kiosco') ||
    text.includes('zaragoza') ||
    text.includes('parque principal') ||
    text.includes('bolero') ||
    text.includes('danzón') ||
    text.includes('danzon') ||
    text.includes('marimba') ||
    text.includes('son campechano') ||
    text.includes('trova') ||
    text.includes('campechanidad') ||
    text.includes('desfile cultural')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.tradicionZaragoza;
  }

  // 14. Gastronomía marina / Camarón / Mariscos / Pescados / Ceviche
  if (
    text.includes('camarón') ||
    text.includes('camaron') ||
    text.includes('marisco') ||
    text.includes('gastronom') ||
    text.includes('culinari') ||
    text.includes('platillo') ||
    text.includes('degustac') ||
    text.includes('chef') ||
    text.includes('ceviche') ||
    text.includes('coctel')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.gastronomiaMariscos;
  }

  // 15. Parrillada / Asados / BBQ / Carnes
  if (
    text.includes('asado') ||
    text.includes('parrill') ||
    text.includes('bbq') ||
    text.includes('carne')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.grill;
  }

  // 16. Café / Repostería / Panadería / Postres
  if (
    text.includes('café') ||
    text.includes('cafe') ||
    text.includes('reposter') ||
    text.includes('postre') ||
    text.includes('panader')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.bakeryCafe;
  }

  // 17. Conciertos / Música en Vivo / Rock / Pop / Bandas
  if (
    text.includes('concierto') ||
    text.includes('música') ||
    text.includes('musica') ||
    text.includes('en vivo') ||
    text.includes('tributo') ||
    text.includes('rock') ||
    text.includes('banda') ||
    text.includes('guitarra') ||
    text.includes('acústic') ||
    text.includes('acustic') ||
    text.includes('recital') ||
    text.includes('jazz') ||
    text.includes('canto') ||
    text.includes('show') ||
    text.includes('blnko') ||
    text.includes('austin') ||
    text.includes('revo') ||
    text.includes('cantautor')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.concert;
  }

  // 18. Fiestas nocturnas / DJ / Electrónica
  if (
    text.includes('dj') ||
    text.includes('electrónica') ||
    text.includes('electronica') ||
    text.includes('fiesta nocturna') ||
    text.includes('antro') ||
    text.includes('club')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.partyNight;
  }

  // 19. Bazares / Emprendedores / Mercaditos / Expo Eventia / Artesanías
  if (
    text.includes('bazar') ||
    text.includes('placita') ||
    text.includes('emprended') ||
    text.includes('artesan') ||
    text.includes('mercadito') ||
    text.includes('expo eventia') ||
    text.includes('tianguis') ||
    text.includes('comercial')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.bazar;
  }

  // 20. Fiestas Patronales / Virgen del Carmen / Procesión
  if (
    text.includes('virgen del carmen') ||
    text.includes('patronal') ||
    text.includes('procesión') ||
    text.includes('procesion') ||
    text.includes('paseo por mar')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.patronalFiesta;
  }

  // 21. Playa Norte / Malecón / Eventos costeros
  if (
    text.includes('playa norte') ||
    text.includes('playa') ||
    text.includes('malecón') ||
    text.includes('malecon') ||
    text.includes('costero')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.beach;
  }

  // 22. Niños / Infantil / Familia
  if (
    text.includes('infantil') ||
    text.includes('niño') ||
    text.includes('niña') ||
    text.includes('títeres') ||
    text.includes('titeres') ||
    text.includes('marioneta') ||
    text.includes('familiar')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.kidsFamily;
  }

  // 23. Mascotas / Perrotón
  if (
    text.includes('mascota') ||
    text.includes('canin') ||
    text.includes('perro') ||
    text.includes('adopci')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.pets;
  }

  // 24. Yoga / Salud / Bienestar
  if (
    text.includes('yoga') ||
    text.includes('meditac') ||
    text.includes('salud') ||
    text.includes('bienestar')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.wellness;
  }

  // 25. Deportes general
  if (
    text.includes('deport') ||
    text.includes('torneo') ||
    text.includes('campeonato')
  ) {
    return THEMATIC_EVENT_IMAGES_SERVER.sportsGeneral;
  }

  // Fallbacks by category
  const cat = (event.categorySlug || event.category || '').toLowerCase();
  if (cat.includes('bazar')) return THEMATIC_EVENT_IMAGES_SERVER.bazar;
  if (cat.includes('gastronom')) return THEMATIC_EVENT_IMAGES_SERVER.gastronomiaMariscos;
  if (cat.includes('deport')) return THEMATIC_EVENT_IMAGES_SERVER.sportsGeneral;
  if (cat.includes('música') || cat.includes('musica')) return THEMATIC_EVENT_IMAGES_SERVER.concert;
  if (cat.includes('cultur') || cat.includes('feria')) return THEMATIC_EVENT_IMAGES_SERVER.tradicionZaragoza;

  return THEMATIC_EVENT_IMAGES_SERVER.tradicionZaragoza;
}

// Load Events from events_db.json
try {
  const evtPath = path.resolve(__dirname, 'events_db.json');
  if (fs.existsSync(evtPath)) {
    const rawEvts = JSON.parse(fs.readFileSync(evtPath, 'utf8'));
    eventsCache = rawEvts.map((e: any) => ({
      ...e,
      image: (e.image && typeof e.image === 'string' && e.image.trim())
        ? e.image.trim()
        : getEventRepresentativeImageServer(e)
    }));
    fs.writeFileSync(evtPath, JSON.stringify(eventsCache, null, 2), 'utf8');
    console.log(`[Cache] ${eventsCache.length} eventos cargados de events_db.json con imágenes representativas.`);
  }
} catch (e) {
  console.warn('[Cache] Error cargando events_db.json:', e);
}

// Load Promotions and Coupons
try {
  const promoPath = path.resolve(__dirname, 'promotions_db.json');
  if (fs.existsSync(promoPath)) {
    promotionsCache = JSON.parse(fs.readFileSync(promoPath, 'utf8'));
    console.log(`[Cache] ${promotionsCache.length} promociones cargadas de promotions_db.json.`);
  } else {
    promotionsCache = [];
    fs.writeFileSync(promoPath, '[]', 'utf8');
  }
} catch (e) {
  console.warn('[Cache] Error cargando promotions_db.json:', e);
  promotionsCache = [];
}

try {
  const couponPath = path.resolve(__dirname, 'coupons_db.json');
  if (fs.existsSync(couponPath)) {
    claimedCouponsCache = JSON.parse(fs.readFileSync(couponPath, 'utf8'));
    console.log(`[Cache] ${claimedCouponsCache.length} cupones cargados de coupons_db.json.`);
  } else {
    claimedCouponsCache = [];
    fs.writeFileSync(couponPath, '[]', 'utf8');
  }
} catch (e) {
  console.warn('[Cache] Error cargando coupons_db.json:', e);
  claimedCouponsCache = [];
}

// Admin Accounts with SHA-256 Crypted Passwords
const ADMIN_SALT = 'carmen_directory_2026_secure_salt';
function hashPassword(pass: string): string {
  return crypto.createHash('sha256').update(pass + ADMIN_SALT).digest('hex');
}

let adminAccounts = [
  {
    username: 'Yuss',
    passwordHash: hashPassword('Gioyuss'),
    role: 'Administrador',
    initial: 'Y',
    avatarColor: 'from-purple-600 to-indigo-600'
  },
  {
    username: 'Jeo',
    passwordHash: hashPassword('63097'),
    role: 'Administrador',
    initial: 'J',
    avatarColor: 'from-blue-600 to-cyan-600'
  }
];

// Helper: Resolve dynamic base URL based on incoming host
function getRequestBaseUrl(req: Request): string {
  const hostHeader = (req.get('x-forwarded-host') || req.get('host') || 'empresasencarmen.com').toLowerCase();
  let domain = 'empresasencarmen.com';
  if (hostHeader.includes('encarmen.org')) {
    domain = 'encarmen.org';
  } else if (hostHeader.includes('encarmen.com')) {
    domain = 'encarmen.com';
  } else if (hostHeader.includes('encarmen.mx')) {
    domain = 'encarmen.mx';
  } else if (hostHeader.includes('empresasencarmen.com')) {
    domain = 'empresasencarmen.com';
  } else {
    domain = hostHeader.split(':')[0];
  }
  const proto = req.get('x-forwarded-proto') || (req.secure ? 'https' : 'http');
  return `${proto}://${domain}`;
}

// Sync Firestore on startup in background
if (firestoreDb) {
  // Sync Events from Firestore
  getDocs(collection(firestoreDb, 'events')).then(snap => {
    if (!snap.empty) {
      const fbEvents: any[] = [];
      snap.forEach(d => fbEvents.push({ id: d.id, ...d.data() }));
      if (fbEvents.length > 0) {
        eventsCache = fbEvents.map((e: any) => {
          const resolvedImg = getEventRepresentativeImageServer(e);
          // If Firestore had no image or a legacy local relative image, write back the full HTTPS image to Firestore permanently
          if (!e.image || !e.image.startsWith('http') || e.image.includes('/uploads/')) {
            updateDoc(doc(firestoreDb, 'events', e.id), {
              image: resolvedImg,
              updatedAt: new Date().toISOString()
            }).then(() => {
              console.log(`[Firestore] Evento "${e.title}" actualizado con imagen permanente en Firebase.`);
            }).catch(uErr => console.warn(`[Firestore] Error actualizando imagen para ${e.id}:`, uErr.message));
          }
          return {
            ...e,
            image: resolvedImg
          };
        });
        fs.writeFileSync(path.resolve(__dirname, 'events_db.json'), JSON.stringify(eventsCache, null, 2), 'utf8');
        console.log(`[Firestore] ${eventsCache.length} eventos sincronizados desde Firestore con imágenes representativas.`);
      }
    }
  }).catch(e => console.warn('[Firestore] Error leyendo events:', e.message));

  // Sync Businesses from Firestore (merge new ones and updates)
  getDocs(collection(firestoreDb, 'businesses')).then(snap => {
    if (!snap.empty) {
      const fbBizMap = new Map<string, any>();
      for (const b of businessesCache) {
        fbBizMap.set(String(b.id), b);
      }
      snap.forEach(d => {
        const data = d.data();
        const bizId = String(data.id || d.id);
        const existing = fbBizMap.get(bizId) || {};
        fbBizMap.set(bizId, { ...existing, ...data, id: isNaN(Number(bizId)) ? bizId : Number(bizId) });
      });
      businessesCache = Array.from(fbBizMap.values());
      console.log(`[Firestore] ${businessesCache.length} empresas sincronizadas desde Firestore (incluyendo nuevos registros).`);
    }
  }).catch(e => console.warn('[Firestore] Error leyendo businesses:', e.message));

  // Sync Promotions from Firestore
  getDocs(collection(firestoreDb, 'promotions')).then(snap => {
    if (!snap.empty) {
      const fbPromos: any[] = [];
      snap.forEach(d => fbPromos.push({ id: d.id, ...d.data() }));
      if (fbPromos.length > 0) {
        promotionsCache = fbPromos;
        fs.writeFileSync(path.resolve(__dirname, 'promotions_db.json'), JSON.stringify(promotionsCache, null, 2), 'utf8');
        console.log(`[Firestore] ${promotionsCache.length} promociones sincronizadas desde Firestore.`);
      }
    }
  }).catch(e => console.warn('[Firestore] Error leyendo promotions:', e.message));

  // Sync Admins from Firestore
  getDoc(doc(firestoreDb, 'system', 'admins')).then(snap => {
    if (snap.exists() && snap.data()?.accounts) {
      adminAccounts = snap.data().accounts;
      console.log('[Firestore] Cuentas de admin sincronizadas desde Firestore.');
    }
  }).catch(e => console.warn('[Firestore] Error leyendo admins:', e.message));
}

// -------------------------------------------------------------
// API ENDPOINTS
// -------------------------------------------------------------

// Version
app.get('/api/version', (_req: Request, res: Response) => {
  let version = '061026:0915';
  try {
    const versionFile = path.resolve(__dirname, 'src/constants/version.ts');
    if (fs.existsSync(versionFile)) {
      const match = fs.readFileSync(versionFile, 'utf8').match(/APP_VERSION = '([^']+)'/);
      if (match) version = match[1];
    }
  } catch (_) {}
  res.json({ success: true, version, serverTime: new Date().toISOString() });
});

// Download complete project ZIP backup for Google Cloud Shell deployment
app.get('/api/download-backup', (req: Request, res: Response) => {
  try {
    let version = '061026-0915';
    try {
      const versionFile = path.resolve(__dirname, 'src/constants/version.ts');
      if (fs.existsSync(versionFile)) {
        const match = fs.readFileSync(versionFile, 'utf8').match(/APP_VERSION = '([^']+)'/);
        if (match) version = match[1].replace(/[:/]/g, '-');
      }
    } catch (_) {}

    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="codigo-fuente-empresasencarmen-${version}.zip"`);

    if (req.method === 'HEAD') {
      return res.status(200).end();
    }

    // Fast static delivery if already pre-built
    const staticZipPath = path.resolve(__dirname, `public/codigo-fuente-empresasencarmen-${version}.zip`);
    const defaultZipPath = path.resolve(__dirname, 'public/codigo-fuente-empresasencarmen.zip');
    if (fs.existsSync(staticZipPath)) {
      return res.sendFile(staticZipPath);
    }
    if (fs.existsSync(defaultZipPath)) {
      return res.sendFile(defaultZipPath);
    }

    const archive = new ZipArchive({ zlib: { level: 9 } });

    archive.on('error', (err: any) => {
      console.error('[Backup ZIP] Error:', err);
      if (!res.headersSent) res.status(500).send('Error generando archivo ZIP');
    });

    archive.pipe(res);

    archive.glob('**/*', {
      cwd: __dirname,
      ignore: [
        'node_modules/**',
        '.git/**',
        'dist/**',
        '*.zip',
        '**/*.zip',
        'public/*.zip',
        'public/wp-content/**',
        'public/uploads/**',
        '.cache/**'
      ],
      dot: true
    });

    archive.finalize();
  } catch (err: any) {
    console.error('Error generating backup zip:', err);
    res.status(500).send('Error generating backup');
  }
});

// Businesses List with search & filters
app.get('/api/businesses', (req: Request, res: Response) => {
  const q = ((req.query.q as string) || '').toLowerCase().trim();
  const category = (req.query.category as string) || '';
  const colonia = (req.query.colonia as string) || '';
  const hasWhatsapp = req.query.hasWhatsapp === 'true';
  const hasDelivery = req.query.hasDelivery === 'true';
  const hasPhone = req.query.hasPhone === 'true';
  const hasAddress = req.query.hasAddress === 'true';

  let list = [...businessesCache];

  if (q) {
    list = list.filter(b =>
      (b.name && b.name.toLowerCase().includes(q)) ||
      (b.description && b.description.toLowerCase().includes(q)) ||
      (b.address && b.address.toLowerCase().includes(q)) ||
      (b.categories && b.categories.some((c: string) => c.toLowerCase().includes(q)))
    );
  }

  if (category && category !== 'all') {
    const catLow = category.toLowerCase();
    list = list.filter(b =>
      (b.categorySlugs && b.categorySlugs.some((s: string) => s.toLowerCase() === catLow)) ||
      (b.categories && b.categories.some((c: string) => c.toLowerCase() === catLow))
    );
  }

  if (colonia && colonia !== 'todas') {
    const colLow = colonia.toLowerCase();
    list = list.filter(b => b.colonia && b.colonia.toLowerCase().includes(colLow));
  }

  if (hasWhatsapp) list = list.filter(b => Boolean(b.whatsapp));
  if (hasDelivery) list = list.filter(b => Boolean(b.hasDelivery));
  if (hasPhone) list = list.filter(b => Boolean(b.phone));
  if (hasAddress) list = list.filter(b => Boolean(b.address));

  res.json({
    total: list.length,
    count: list.length,
    offset: 0,
    limit: list.length,
    businesses: list
  });
});

// Single Business
app.get('/api/businesses/:id', (req: Request, res: Response) => {
  const idOrSlug = req.params.id;
  const biz = businessesCache.find(b =>
    String(b.id) === idOrSlug ||
    (b.slug && b.slug.toLowerCase() === idOrSlug.toLowerCase())
  );
  if (biz) {
    res.json({ success: true, business: biz });
  } else {
    res.status(404).json({ success: false, message: 'Empresa no encontrada' });
  }
});

// Categories
app.get('/api/categories', (_req: Request, res: Response) => {
  const parents = categoriesCache.filter(c => c.parent === 0 && c.id !== 15 && c.slug !== 'uncategorized');
  const topCategories = parents.map(p => {
    const subcategories = categoriesCache.filter(c => c.parent === p.id);
    return {
      ...p,
      subcategories
    };
  });

  res.json({
    total: categoriesCache.length,
    topCategories,
    allCategories: categoriesCache
  });
});

// Events
app.get('/api/events', (_req: Request, res: Response) => {
  const eventsWithImages = eventsCache.map((e: any) => ({
    ...e,
    image: (e.image && typeof e.image === 'string' && e.image.trim())
      ? e.image.trim()
      : getEventRepresentativeImageServer(e)
  }));
  res.json({ success: true, events: eventsWithImages });
});

app.post('/api/events', async (req: Request, res: Response) => {
  try {
    const newEvent = {
      id: req.body.id || `evt-${Date.now()}`,
      title: req.body.title || '',
      category: req.body.category || 'Cultura & Música',
      categorySlug: req.body.categorySlug || 'cultura',
      date: req.body.date || '',
      time: req.body.time || '',
      location: req.body.location || 'Ciudad del Carmen',
      cost: req.body.cost || 'Entrada Libre',
      description: req.body.description || '',
      organizer: req.body.organizer || '',
      badge: req.body.badge || '',
      icon: req.body.icon || 'Calendar',
      image: req.body.image || '',
      updatedAt: new Date().toISOString()
    };

    eventsCache = [newEvent, ...eventsCache.filter(e => e.id !== newEvent.id)];
    fs.writeFileSync(path.resolve(__dirname, 'events_db.json'), JSON.stringify(eventsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'events', newEvent.id), newEvent);
      } catch (fErr) {
        console.warn('Error saving event to Firestore:', fErr);
      }
    }

    res.json({ success: true, event: newEvent });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.put('/api/events/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    const idx = eventsCache.findIndex(e => e.id === id);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Evento no encontrado' });
    }

    const updated = {
      ...eventsCache[idx],
      ...req.body,
      id,
      updatedAt: new Date().toISOString()
    };
    eventsCache[idx] = updated;
    fs.writeFileSync(path.resolve(__dirname, 'events_db.json'), JSON.stringify(eventsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'events', id), updated);
      } catch (fErr) {
        console.warn('Error updating event in Firestore:', fErr);
      }
    }

    res.json({ success: true, event: updated });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

app.delete('/api/events/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    eventsCache = eventsCache.filter(e => e.id !== id);
    fs.writeFileSync(path.resolve(__dirname, 'events_db.json'), JSON.stringify(eventsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await deleteDoc(doc(firestoreDb, 'events', id));
      } catch (fErr) {
        console.warn('Error deleting event from Firestore:', fErr);
      }
    }

    res.json({ success: true, message: 'Evento eliminado' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ==========================================
// PROMOCIONES Y CUPONES FLASH (Endpoints API)
// ==========================================

// Obtener todas las promociones activas para catálogo público
app.get('/api/promotions', (_req: Request, res: Response) => {
  res.json({
    success: true,
    count: promotionsCache.length,
    promotions: promotionsCache
  });
});

// Obtener la promoción activa de una empresa específica
app.get('/api/promotions/business/:businessId', (req: Request, res: Response) => {
  const bId = Number(req.params.businessId);
  const promo = promotionsCache.find(p => p.businessId === bId);
  res.json({
    success: true,
    promotion: promo || null
  });
});

// Reclamar cupón con nombre y teléfono del cliente
app.post('/api/promotions/:promotionId/claim', async (req: Request, res: Response) => {
  try {
    const promoId = req.params.promotionId;
    const { customerName, customerPhone } = req.body;
    const promoIdx = promotionsCache.findIndex(p => p.id === promoId);
    if (promoIdx === -1) {
      return res.status(404).json({ success: false, message: 'Promoción no encontrada' });
    }

    const promo = promotionsCache[promoIdx];
    const code = `CPN-${Math.random().toString(36).substring(2, 7).toUpperCase()}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newCoupon = {
      id: `cpn-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
      promotionId: promo.id,
      promotionTitle: promo.title,
      businessId: promo.businessId,
      businessName: promo.businessName,
      businessWhatsapp: promo.businessWhatsapp || '',
      businessPhone: promo.businessPhone || '',
      discount: promo.discount,
      code,
      claimedAt: new Date().toISOString(),
      customerName: (customerName || 'Cliente').trim(),
      customerPhone: (customerPhone || '').trim(),
      status: 'active'
    };

    claimedCouponsCache.unshift(newCoupon);
    promo.claimedCount = (promo.claimedCount || 0) + 1;
    promotionsCache[promoIdx] = promo;

    fs.writeFileSync(path.resolve(__dirname, 'promotions_db.json'), JSON.stringify(promotionsCache, null, 2), 'utf8');
    fs.writeFileSync(path.resolve(__dirname, 'coupons_db.json'), JSON.stringify(claimedCouponsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'claimed_coupons', newCoupon.id), newCoupon);
        await setDoc(doc(firestoreDb, 'promotions', promo.id), promo);
      } catch (fErr) {
        console.warn('Error saving claimed coupon to Firestore:', fErr);
      }
    }

    const max = promo.totalCoupons || promo.maxClaims || 50;
    const remaining = Math.max(0, max - promo.claimedCount);

    res.json({
      success: true,
      message: '¡Cupón reclamado con éxito!',
      coupon: newCoupon,
      remainingCoupons: remaining
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Obtener lista completa de promociones
app.get('/api/admin/promotions', (_req: Request, res: Response) => {
  res.json({
    success: true,
    count: promotionsCache.length,
    promotions: promotionsCache,
    adminAlertEmails: []
  });
});

// Admin: Crear o editar promoción
app.post('/api/admin/promotions', async (req: Request, res: Response) => {
  try {
    const promoData = req.body;
    const id = promoData.id || `promo-${Date.now()}`;
    const savedPromo = {
      ...promoData,
      id,
      updatedAt: new Date().toISOString()
    };

    const idx = promotionsCache.findIndex(p => p.id === id);
    if (idx >= 0) {
      promotionsCache[idx] = savedPromo;
    } else {
      promotionsCache.unshift(savedPromo);
    }

    fs.writeFileSync(path.resolve(__dirname, 'promotions_db.json'), JSON.stringify(promotionsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'promotions', id), savedPromo);
      } catch (fErr) {
        console.warn('Error saving admin promo to Firestore:', fErr);
      }
    }

    res.json({
      success: true,
      message: 'Promoción guardada con éxito',
      promotion: savedPromo
    });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Eliminar promoción
app.delete('/api/admin/promotions/:id', async (req: Request, res: Response) => {
  try {
    const id = req.params.id;
    promotionsCache = promotionsCache.filter(p => p.id !== id);
    fs.writeFileSync(path.resolve(__dirname, 'promotions_db.json'), JSON.stringify(promotionsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await deleteDoc(doc(firestoreDb, 'promotions', id));
      } catch (fErr) {
        console.warn('Error deleting promo from Firestore:', fErr);
      }
    }

    res.json({ success: true, message: 'Promoción eliminada con éxito' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Listar cupones emitidos
app.get('/api/admin/coupons', (_req: Request, res: Response) => {
  res.json({
    success: true,
    count: claimedCouponsCache.length,
    coupons: claimedCouponsCache,
    notifications: [],
    adminAlertEmails: []
  });
});

// Admin: Cambiar estado de cupón (canjeado, activo, cancelado)
app.post('/api/admin/coupons/:couponId/status', async (req: Request, res: Response) => {
  try {
    const couponId = req.params.couponId;
    const { status } = req.body;
    const idx = claimedCouponsCache.findIndex(c => c.id === couponId || c.code === couponId);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Cupón no encontrado' });
    }

    claimedCouponsCache[idx].status = status;
    fs.writeFileSync(path.resolve(__dirname, 'coupons_db.json'), JSON.stringify(claimedCouponsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'claimed_coupons', claimedCouponsCache[idx].id), { status });
      } catch (fErr) {
        console.warn('Error updating coupon in Firestore:', fErr);
      }
    }

    res.json({ success: true, message: 'Estado del cupón actualizado', coupon: claimedCouponsCache[idx] });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Canjear cupón por código
app.post('/api/admin/coupons/:code/redeem', async (req: Request, res: Response) => {
  try {
    const code = req.params.code;
    const idx = claimedCouponsCache.findIndex(c => c.code === code || c.id === code);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Cupón no encontrado con ese código' });
    }

    claimedCouponsCache[idx].status = 'redeemed';
    fs.writeFileSync(path.resolve(__dirname, 'coupons_db.json'), JSON.stringify(claimedCouponsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'claimed_coupons', claimedCouponsCache[idx].id), { status: 'redeemed' });
      } catch (fErr) {
        console.warn('Error redeeming coupon in Firestore:', fErr);
      }
    }

    res.json({ success: true, message: 'Cupón canjeado con éxito', coupon: claimedCouponsCache[idx] });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Admin: Eliminar cupón
app.delete('/api/admin/coupons/:couponId', async (req: Request, res: Response) => {
  try {
    const couponId = req.params.couponId;
    claimedCouponsCache = claimedCouponsCache.filter(c => c.id !== couponId && c.code !== couponId);
    fs.writeFileSync(path.resolve(__dirname, 'coupons_db.json'), JSON.stringify(claimedCouponsCache, null, 2), 'utf8');

    if (firestoreDb) {
      try {
        await deleteDoc(doc(firestoreDb, 'claimed_coupons', couponId));
      } catch (fErr) {
        console.warn('Error deleting coupon from Firestore:', fErr);
      }
    }

    res.json({ success: true, message: 'Cupón eliminado' });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// ==========================================
// RADAR DE EVENTOS CON IA (Google Search Grounding)
// ==========================================
let lastRadarScanTimestamp: string | null = null;
let lastRadarNewEventsCount: number = 0;

function normalizeString(str: string): string {
  return (str || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

function isSimilarEvent(existingTitle: string, newTitle: string): boolean {
  const norm1 = normalizeString(existingTitle);
  const norm2 = normalizeString(newTitle);
  if (norm1 === norm2) return true;
  if (norm1.includes(norm2) || norm2.includes(norm1)) return true;

  const words1 = norm1.split(/\s+/).filter(w => w.length > 3);
  const words2 = norm2.split(/\s+/).filter(w => w.length > 3);
  const common = words1.filter(w => words2.includes(w));
  if (common.length >= 2 && (common.length / Math.min(words1.length || 1, words2.length || 1)) >= 0.6) {
    return true;
  }
  return false;
}

// Radar de eventos en modo local ($0 costo de API)
async function runAIRadarScan(): Promise<{
  success: boolean;
  message: string;
  scannedAt: string;
  foundCount: number;
  newEventsAdded: number;
  totalEvents: number;
  newEvents: any[];
  allEvents: any[];
}> {
  console.log('[Radar Local] Escaneo ejecutado en modo económico sin costo de API.');
  lastRadarScanTimestamp = new Date().toISOString();
  lastRadarNewEventsCount = 0;

  return {
    success: true,
    message: 'Cartelera actualizada desde la base de datos sin llamadas a APIs externas de pago ($0 costo).',
    scannedAt: lastRadarScanTimestamp,
    foundCount: eventsCache.length,
    newEventsAdded: 0,
    totalEvents: eventsCache.length,
    newEvents: [],
    allEvents: eventsCache
  };
}

// Endpoint para búsqueda de eventos en cartelera (Modo 100% Gratuito - Cero llamadas a APIs de pago)
app.post('/api/events/radar-search', async (req: Request, res: Response) => {
  try {
    const userQuery = (req.body?.query || '').toLowerCase().trim();
    console.log(`[Búsqueda de Eventos Local ($0 Costo)] Consulta recibida: "${userQuery}"`);

    // Búsqueda instantánea en memoria sin consumir tokens de Gemini ni Google Search API
    let matchedEvents = [...eventsCache];

    if (userQuery) {
      matchedEvents = eventsCache.filter(e => {
        const titleMatch = (e.title || '').toLowerCase().includes(userQuery);
        const descMatch = (e.description || '').toLowerCase().includes(userQuery);
        const catMatch = (e.category || '').toLowerCase().includes(userQuery) || (e.categorySlug || '').toLowerCase().includes(userQuery);
        const locMatch = (e.location || '').toLowerCase().includes(userQuery);
        const orgMatch = (e.organizer || '').toLowerCase().includes(userQuery);
        return titleMatch || descMatch || catMatch || locMatch || orgMatch;
      });

      // Si no hay coincidencias exactas por palabra clave, mostrar los eventos más relevantes
      if (matchedEvents.length === 0) {
        matchedEvents = eventsCache.slice(0, 8);
      }
    }

    const candidates = matchedEvents.map((raw: any) => {
      const candidateImg = getEventRepresentativeImageServer(raw);
      return {
        id: raw.id,
        title: raw.title,
        category: raw.category || 'Cultura & Música',
        categorySlug: raw.categorySlug || 'cultura',
        date: raw.date || 'Próximamente',
        time: raw.time || 'Horario por confirmar',
        location: raw.location || 'Ciudad del Carmen, Campeche',
        cost: raw.cost || 'Entrada Libre',
        description: raw.description || '',
        organizer: raw.organizer || 'Organizador en Carmen',
        badge: raw.badge || 'Cartelera Local',
        icon: raw.icon || 'Calendar',
        image: candidateImg,
        sourceUrl: raw.sourceUrl || 'https://carmen.gob.mx',
        alreadyPublished: true,
        publishedEventId: raw.id
      };
    });

    res.json({
      success: true,
      query: userQuery,
      totalFound: candidates.length,
      isLocalFreeMode: true,
      costEstimate: '$0.00 MXN',
      candidates
    });
  } catch (err: any) {
    console.error('[Event Search Error]:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Error al ejecutar la búsqueda de eventos.'
    });
  }
});

// Endpoint para publicar candidatos seleccionados por el usuario
app.post('/api/events/publish-candidates', async (req: Request, res: Response) => {
  try {
    const { events } = req.body;
    if (!Array.isArray(events) || events.length === 0) {
      return res.status(400).json({
        success: false,
        message: 'No se recibieron eventos para publicar.'
      });
    }

    const newlyAdded: any[] = [];
    const nowIso = new Date().toISOString();

    for (const rawEvt of events) {
      if (!rawEvt.title || !rawEvt.title.trim()) continue;

      const alreadyExists = eventsCache.some(existing => 
        isSimilarEvent(existing.title, rawEvt.title)
      );

      if (alreadyExists) {
        console.log(`[Publicar Candidatos] Evento omitido por ya existir: "${rawEvt.title}"`);
        continue;
      }

      // Asegurar imagen representativa según el título
      let eventImage = (rawEvt.image && typeof rawEvt.image === 'string' && rawEvt.image.trim())
        ? rawEvt.image.trim()
        : '';

      if (!eventImage) {
        eventImage = getEventRepresentativeImageServer(rawEvt);
      }

      const newId = `evt-ai-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`;
      const newEvent = {
        id: newId,
        title: rawEvt.title.trim(),
        category: rawEvt.category || 'Cultura & Música',
        categorySlug: rawEvt.categorySlug || 'cultura',
        date: rawEvt.date || 'Próximamente',
        time: rawEvt.time || 'Horario por confirmar',
        location: rawEvt.location || 'Ciudad del Carmen, Campeche',
        cost: rawEvt.cost || 'Entrada Libre',
        description: rawEvt.description || '',
        organizer: rawEvt.organizer || 'Organizador en Carmen',
        badge: rawEvt.badge || 'Radar IA',
        icon: rawEvt.icon || 'Calendar',
        image: eventImage,
        sourceUrl: rawEvt.sourceUrl || 'https://carmen.gob.mx',
        aiDetected: true,
        updatedAt: nowIso
      };

      eventsCache = [newEvent, ...eventsCache];
      newlyAdded.push(newEvent);

      if (firestoreDb) {
        try {
          await setDoc(doc(firestoreDb, 'events', newId), newEvent);
        } catch (fErr: any) {
          console.warn('[Firestore] Error guardando evento publicado:', fErr.message);
        }
      }
    }

    if (newlyAdded.length > 0) {
      fs.writeFileSync(path.resolve(__dirname, 'events_db.json'), JSON.stringify(eventsCache, null, 2), 'utf8');
      console.log(`[Radar IA] ${newlyAdded.length} eventos seleccionados y publicados en la cartelera con imágenes representativas.`);
    }

    res.json({
      success: true,
      count: newlyAdded.length,
      published: newlyAdded,
      events: eventsCache,
      message: `Se publicaron exitosamente ${newlyAdded.length} evento(s) en la cartelera.`
    });
  } catch (err: any) {
    console.error('[Publish Candidates Error]:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Error al publicar los eventos seleccionados.'
    });
  }
});

// Endpoint para activar el Radar de Revisión IA (Legacy auto-scan)
app.post('/api/events/radar-scan', async (_req: Request, res: Response) => {
  try {
    const result = await runAIRadarScan();
    res.json(result);
  } catch (err: any) {
    console.error('[Radar IA Error]:', err);
    res.status(500).json({
      success: false,
      message: err.message || 'Error al ejecutar el Radar de Eventos IA.'
    });
  }
});

// Endpoint para consultar estado del Radar
app.get('/api/events/radar-status', (_req: Request, res: Response) => {
  const aiDetectedCount = eventsCache.filter(e => e.aiDetected).length;
  res.json({
    success: true,
    lastScan: lastRadarScanTimestamp,
    lastAddedCount: lastRadarNewEventsCount,
    totalEvents: eventsCache.length,
    aiDetectedCount
  });
});

// Admin Accounts
app.get('/api/admin/accounts', (_req: Request, res: Response) => {
  res.json({
    success: true,
    accounts: adminAccounts.map(a => ({
      username: a.username,
      role: a.role,
      initial: a.initial,
      avatarColor: a.avatarColor
    }))
  });
});

app.post('/api/admin/login', (req: Request, res: Response) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ success: false, error: 'Usuario y contraseña requeridos' });
  }

  const user = adminAccounts.find(a => a.username.toLowerCase() === username.toLowerCase());
  if (!user) {
    return res.status(401).json({ success: false, error: 'Usuario no encontrado' });
  }

  const hash = hashPassword(password.trim());
  if (hash === user.passwordHash) {
    res.json({ success: true, message: 'Autenticación exitosa', username: user.username });
  } else {
    res.status(401).json({ success: false, error: 'Contraseña incorrecta' });
  }
});

app.post('/api/admin/change-password', async (req: Request, res: Response) => {
  const { username, newPassword } = req.body;
  if (!username || !newPassword || newPassword.trim().length < 3) {
    return res.status(400).json({ success: false, error: 'Datos inválidos' });
  }

  const userIdx = adminAccounts.findIndex(a => a.username.toLowerCase() === username.toLowerCase());
  if (userIdx === -1) {
    return res.status(404).json({ success: false, error: 'Usuario no encontrado' });
  }

  adminAccounts[userIdx].passwordHash = hashPassword(newPassword.trim());

  if (firestoreDb) {
    try {
      await setDoc(doc(firestoreDb, 'system', 'admins'), {
        accounts: adminAccounts,
        updatedAt: new Date().toISOString()
      });
    } catch (fErr) {
      console.warn('Error saving admin passwords to Firestore:', fErr);
    }
  }

  res.json({ success: true, message: `Contraseña de ${username} actualizada con éxito` });
});

// Upload Logo / Image
app.post('/api/upload-logo', async (req: Request, res: Response) => {
  try {
    const rawImage = req.body.imageBase64 || req.body.image;
    const { filename } = req.body;
    if (!rawImage || typeof rawImage !== 'string') {
      return res.status(400).json({ success: false, message: 'No se envió imagen válida.' });
    }

    const matches = rawImage.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let mimeType = 'image/png';
    let base64Data = rawImage;

    if (matches && matches.length === 3) {
      mimeType = matches[1];
      base64Data = matches[2];
    } else {
      base64Data = rawImage.replace(/^data:image\/\w+;base64,/, '');
    }

    const buffer = Buffer.from(base64Data, 'base64');
    const safeFilename = filename
      ? path.basename(filename).replace(/[^a-zA-Z0-9.-]/g, '_')
      : `img-${Date.now()}-${Math.floor(Math.random() * 10000)}.png`;

    const uploadsDir = path.resolve(__dirname, 'public/uploads');
    fs.mkdirSync(uploadsDir, { recursive: true });
    fs.writeFileSync(path.join(uploadsDir, safeFilename), buffer);

    if (firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'uploaded_images', safeFilename), {
          data: base64Data,
          mimeType,
          filename: safeFilename,
          updatedAt: new Date().toISOString()
        });
      } catch (fErr) {
        console.warn('Error saving image to Firestore uploaded_images:', fErr);
      }
    }

    res.json({ success: true, url: `/uploads/${safeFilename}`, filename: safeFilename });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// Serve uploaded images with Firestore & live production fallback
app.get('/uploads/:filename', async (req: Request, res: Response) => {
  const rawParam = req.params.filename || '';
  const filename = path.basename(rawParam);

  // Security check: Must be a valid image filename, no traversal, no hidden files
  const SAFE_IMG_NAME = /^[a-zA-Z0-9_\-\.]+\.(jpg|jpeg|png|webp|svg|gif|ico)$/i;
  if (!SAFE_IMG_NAME.test(filename) || filename.includes('..') || filename.startsWith('.')) {
    return res.status(404).send('Invalid image filename');
  }

  const localFile = path.resolve(__dirname, 'public/uploads', filename);

  if (fs.existsSync(localFile)) {
    return res.sendFile(localFile);
  }

  if (firestoreDb) {
    try {
      const imgDoc = await getDoc(doc(firestoreDb, 'uploaded_images', filename));
      if (imgDoc.exists() && imgDoc.data()?.data) {
        const data = imgDoc.data();
        const buffer = Buffer.from(data.data, 'base64');
        const uploadsDir = path.resolve(__dirname, 'public/uploads');
        fs.mkdirSync(uploadsDir, { recursive: true });
        fs.writeFileSync(localFile, buffer);
        res.setHeader('Content-Type', data.mimeType || 'image/jpeg');
        return res.send(buffer);
      }
    } catch (_) {}
  }

  res.status(404).send('Image not found');
});

// Robots.txt
app.get('/robots.txt', (req: Request, res: Response) => {
  const baseUrl = getRequestBaseUrl(req);
  const robots = `User-agent: *\nAllow: /\nDisallow: /api/\n\nSitemap: ${baseUrl}/sitemap.xml\nSitemap: https://empresasencarmen.com/sitemap.xml\nSitemap: https://encarmen.org/sitemap.xml\n`;
  res.setHeader('Content-Type', 'text/plain; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(robots);
});

// Sitemap.xml
app.get('/sitemap.xml', (req: Request, res: Response) => {
  const baseUrl = getRequestBaseUrl(req);
  const today = new Date().toISOString().split('T')[0];

  let xml = '<?xml version="1.0" encoding="UTF-8"?>\n';
  xml += '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n';

  xml += `  <url>\n    <loc>${baseUrl}/</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>daily</changefreq>\n    <priority>1.0</priority>\n  </url>\n`;
  xml += `  <url>\n    <loc>${baseUrl}/eventos</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.9</priority>\n  </url>\n`;
  xml += `  <url>\n    <loc>${baseUrl}/emergencias</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>monthly</changefreq>\n    <priority>0.8</priority>\n  </url>\n`;

  const parents = categoriesCache.filter(c => c.parent === 0 && c.id !== 15 && c.slug !== 'uncategorized');
  for (const cat of parents) {
    if (cat.slug) {
      xml += `  <url>\n    <loc>${baseUrl}/categoria/${encodeURIComponent(cat.slug)}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.8</priority>\n  </url>\n`;
    }
  }

  for (const b of businessesCache) {
    if (b.slug) {
      xml += `  <url>\n    <loc>${baseUrl}/empresa/${encodeURIComponent(b.slug)}</loc>\n    <lastmod>${today}</lastmod>\n    <changefreq>weekly</changefreq>\n    <priority>0.7</priority>\n  </url>\n`;
    }
  }

  xml += '</urlset>';

  res.setHeader('Content-Type', 'application/xml; charset=utf-8');
  res.setHeader('Cache-Control', 'public, max-age=86400');
  res.send(xml);
});

// Static assets from public and dist with Cache-Control headers to drastically cut Cloud Run requests
const oneDayMs = 24 * 60 * 60 * 1000;
const oneWeekMs = 7 * oneDayMs;

app.use(express.static(path.resolve(__dirname, 'public'), {
  maxAge: oneDayMs,
  setHeaders: (res, filePath) => {
    if (/\.(jpg|jpeg|png|webp|svg|gif|ico|woff2?|ttf)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=604800, immutable');
    }
  }
}));

app.use(express.static(path.resolve(__dirname, 'dist'), {
  maxAge: oneWeekMs,
  setHeaders: (res, filePath) => {
    if (/\.(js|css|woff2?|png|jpg|svg|webp)$/i.test(filePath)) {
      res.setHeader('Cache-Control', 'public, max-age=2592000, immutable');
    }
  }
}));

// Client Routing fallback with OpenGraph and Schema.org
app.get('*', (req: Request, res: Response) => {
  if (
    req.path.startsWith('/api/') ||
    req.path.startsWith('/uploads/') ||
    /\.(jpg|jpeg|png|webp|svg|gif|ico|css|js|map|json|woff2?|ttf)$/i.test(req.path)
  ) {
    return res.status(404).setHeader('Content-Type', 'text/plain').send('File not found');
  }

  const indexPath = path.resolve(__dirname, 'dist/index.html');
  if (fs.existsSync(indexPath)) {
    let html = fs.readFileSync(indexPath, 'utf8');
    const cleanPath = req.path.replace(/^\/+|\/+$/g, '').replace(/^(empresa|producto)\//i, '');
    const queryEmpresa = req.query.empresa as string;
    const candidateSlug = queryEmpresa || cleanPath;

    if (candidateSlug && businessesCache && businessesCache.length > 0) {
      const biz = businessesCache.find(b =>
        b.slug?.toLowerCase() === candidateSlug.toLowerCase() ||
        String(b.id) === candidateSlug
      );

      if (biz) {
        const baseUrl = getRequestBaseUrl(req);
        const ogTitle = `${biz.name} | Tarjeta Digital - Empresas en Carmen`;
        const ogDesc = `${biz.address ? `${biz.address}. ` : ''}${biz.phone ? `Tel: ${biz.phone}. ` : ''}${biz.description ? biz.description.slice(0, 140) : 'Directorio Comercial de Ciudad del Carmen'}`;
        const ogImage = biz.image || 'https://empresasencarmen.com/icons/icon-512.svg';
        const bizUrl = `${baseUrl}/empresa/${biz.slug}`;

        html = html.replace(/<title>.*?<\/title>/i, `<title>${ogTitle}</title>`);
        html = html.replace(/<meta property="og:title"[^>]*>/i, `<meta property="og:title" content="${ogTitle}" />`);
        html = html.replace(/<meta property="og:description"[^>]*>/i, `<meta property="og:description" content="${ogDesc}" />`);
        html = html.replace('</head>', `  <link rel="canonical" href="${bizUrl}" />\n  <meta property="og:url" content="${bizUrl}" />\n</head>`);
      }
    }

    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
    return res.send(html);
  }

  res.status(500).send('dist/index.html not found');
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`[Express] Servidor corriendo exitosamente en http://0.0.0.0:${PORT}`);
});
