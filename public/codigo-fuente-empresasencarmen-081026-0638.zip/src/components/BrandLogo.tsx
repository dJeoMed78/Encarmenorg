import React from 'react';

interface BrandLogoProps {
  className?: string;
  showSubtitle?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = 'h-10 sm:h-12 w-auto'
}) => {
  return (
    <img
      src="/images/logo-oficial.png"
      alt="Empresas en Carmen"
      className={`${className} object-contain select-none`}
      loading="eager"
      onError={(e) => {
        const target = e.target as HTMLImageElement;
        target.onerror = null;
        target.src = 'https://empresasencarmen.com/wp-content/uploads/2024/07/empresas3001.png';
      }}
    />
  );
};
