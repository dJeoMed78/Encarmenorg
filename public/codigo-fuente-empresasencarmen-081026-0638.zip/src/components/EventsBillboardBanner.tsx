import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  Calendar,
  Clock,
  MapPin,
  Tag,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  Sparkles,
  Music,
  ShoppingBag,
  PartyPopper,
  Flame,
  Info,
  X,
  Maximize2,
  PlusCircle,
  Edit2,
  Trash2,
  ShieldCheck,
  Building2,
  Phone,
  Radio,
  Bot,
  Loader2,
  Search,
  AlertCircle,
  CheckCircle2
} from 'lucide-react';
import {
  EventItem,
  getEventsData,
  initEventsRealtimeSync,
  addEventItem,
  updateEventItem,
  deleteEventItem,
  searchAIRadarCandidates
} from '../services/eventsService';
import { isSessionAdminAuthenticated } from '../utils/adminAuth';
import { getEventRepresentativeImage } from '../utils/eventImages';

interface EventsBillboardBannerProps {
  onOpenEmergencyGuide?: () => void;
}

export const EventsBillboardBanner: React.FC<EventsBillboardBannerProps> = ({
  onOpenEmergencyGuide
}) => {
  const [events, setEvents] = useState<EventItem[]>(() => getEventsData());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentPage, setCurrentPage] = useState<number>(0);
  const [selectedEvent, setSelectedEvent] = useState<EventItem | null>(null);
  const [isFullModalOpen, setIsFullModalOpen] = useState(false);
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string } | null>(null);
  const [isAdmin, setIsAdmin] = useState(() => isSessionAdminAuthenticated());
  const [isHovered, setIsHovered] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isAiSearching, setIsAiSearching] = useState(false);
  const [aiSearchNotification, setAiSearchNotification] = useState<{ text: string; type: 'success' | 'warning' | 'error' } | null>(null);

  const [isEditorOpen, setIsEditorOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState<EventItem | null>(null);

  const isAiStudioEnv = typeof window !== 'undefined' && (
    window.location.hostname.includes('run.app') || 
    window.location.hostname === 'localhost' || 
    window.location.hostname === '127.0.0.1'
  );

  const handleDeleteEvent = async (evtId: string, title: string) => {
    if (window.confirm(`¿Estás seguro de eliminar "${title}" de la cartelera?`)) {
      await deleteEventItem(evtId);
      if (selectedEvent?.id === evtId) {
        setSelectedEvent(null);
      }
    }
  };

  const handleOpenEditEvent = (evt: EventItem, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setEditingEvent(evt);
    setEventForm({
      title: evt.title || '',
      category: evt.category || 'Música',
      categorySlug: evt.categorySlug || 'cultura',
      date: evt.date || '',
      time: evt.time || '',
      location: evt.location || '',
      cost: evt.cost || 'Entrada Libre',
      description: evt.description || '',
      organizer: evt.organizer || '',
      badge: evt.badge || 'Radar IA',
      icon: evt.icon || 'Calendar',
      image: evt.image || '',
      sourceUrl: evt.sourceUrl || ''
    });
    setIsEditorOpen(true);
  };

  const handleSaveEvent = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingEvent) return;
    await updateEventItem(editingEvent.id, eventForm);
    setIsEditorOpen(false);
    if (selectedEvent && selectedEvent.id === editingEvent.id) {
      setSelectedEvent({ ...editingEvent, ...eventForm });
    }
    setEditingEvent(null);
  };

  const [eventForm, setEventForm] = useState({
    title: '',
    category: 'Música',
    categorySlug: 'cultura',
    date: '',
    time: '',
    location: '',
    cost: 'Entrada Libre',
    description: '',
    organizer: '',
    badge: 'Ambiente Familiar',
    icon: 'Music',
    image: '',
    sourceUrl: ''
  });

  useEffect(() => {
    const unsub = initEventsRealtimeSync();
    const handleUpdate = () => {
      setEvents([...getEventsData()]);
      setIsAdmin(isSessionAdminAuthenticated());
    };
    window.addEventListener('events-billboard-updated', handleUpdate);
    window.addEventListener('admin-auth-changed', handleUpdate);

    return () => {
      unsub();
      window.removeEventListener('events-billboard-updated', handleUpdate);
      window.removeEventListener('admin-auth-changed', handleUpdate);
    };
  }, []);

  const categories = useMemo(() => {
    const map = new Map<string, string>();
    map.set('all', 'Todos los Eventos');
    events.forEach(e => {
      if (e.categorySlug && e.category) {
        map.set(e.categorySlug, e.category);
      }
    });
    return Array.from(map.entries()).map(([slug, name]) => ({ slug, name }));
  }, [events]);

  const filteredEvents = useMemo(() => {
    let list = events;
    if (selectedCategory !== 'all') {
      list = list.filter(e => e.categorySlug === selectedCategory);
    }
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      list = list.filter(e =>
        e.title.toLowerCase().includes(q) ||
        (e.location && e.location.toLowerCase().includes(q)) ||
        (e.description && e.description.toLowerCase().includes(q)) ||
        (e.category && e.category.toLowerCase().includes(q)) ||
        (e.organizer && e.organizer.toLowerCase().includes(q))
      );
    }
    return list;
  }, [events, selectedCategory, searchQuery]);

  const handleAiSearch = async () => {
    setIsAiSearching(true);
    setAiSearchNotification(null);
    try {
      const res = await searchAIRadarCandidates(searchQuery || 'eventos carmelitas', true);
      if (res.success && res.candidates?.length) {
        if (res.aiInfo?.quotaExhausted) {
          setAiSearchNotification({
            text: res.aiInfo.message || '⚠️ Las llamadas gratuitas de la API de Gemini se han agotado por hoy (límite de cuota diaria alcanzado). El servicio gratuito de Google se restablecerá automáticamente mañana.',
            type: 'warning'
          });
        } else if (res.aiInfo?.message) {
          setAiSearchNotification({
            text: res.aiInfo.message,
            type: 'success'
          });
        } else {
          setAiSearchNotification({
            text: `Radar IA: Se detectaron ${res.candidates.length} eventos potenciales en Carmen.`,
            type: 'success'
          });
        }
      }
    } catch (err: any) {
      setAiSearchNotification({
        text: err.message || 'Error al conectar con la IA de eventos.',
        type: 'error'
      });
    } finally {
      setIsAiSearching(false);
      setTimeout(() => setAiSearchNotification(null), 8000);
    }
  };

  // PAGINATION & AUTO-SLIDE LOGIC
  // If items <= 4, visible in a single 4-item view. Total pages = ceil(count / 4)
  const itemsPerPage = 4;
  const totalPages = Math.ceil(filteredEvents.length / itemsPerPage);

  // Reset page when category changes or event count changes
  useEffect(() => {
    setCurrentPage(0);
  }, [selectedCategory, filteredEvents.length]);

  // Auto-slide only if more than 4 items (totalPages > 1) and not paused
  useEffect(() => {
    if (totalPages <= 1 || isHovered || isFullModalOpen || isEditorOpen || Boolean(selectedEvent)) return;

    const interval = setInterval(() => {
      setCurrentPage(prev => (prev + 1 >= totalPages ? 0 : prev + 1));
    }, 6000);

    return () => clearInterval(interval);
  }, [totalPages, isHovered, isFullModalOpen, isEditorOpen, selectedEvent]);

  const handlePrevPage = () => {
    setCurrentPage(prev => (prev - 1 < 0 ? Math.max(0, totalPages - 1) : prev - 1));
  };

  const handleNextPage = () => {
    setCurrentPage(prev => (prev + 1 >= totalPages ? 0 : prev + 1));
  };

  if (events.length === 0 && !isAdmin) {
    return null;
  }

  const renderEventCard = (evt: EventItem) => {
    const cardImg = getEventRepresentativeImage(evt);
    return (
      <div
        key={evt.id}
        onClick={() => setSelectedEvent(evt)}
        className="bg-stone-850/90 border border-stone-800 hover:border-amber-400/70 rounded-2xl p-4 flex flex-col justify-between transition-all hover:bg-stone-800 group shadow-md hover:shadow-xl cursor-pointer text-left h-full"
      >
        <div className="space-y-3">
          <div
            onClick={e => {
              e.stopPropagation();
              setLightboxImage({ url: cardImg, title: evt.title });
            }}
            className="relative h-36 w-full rounded-xl overflow-hidden cursor-pointer group/img border border-stone-700/60 bg-stone-900"
          >
            <img
              src={cardImg}
              alt={evt.title}
              referrerPolicy="no-referrer"
              onError={(e) => {
                const imgEl = e.currentTarget as HTMLImageElement;
                imgEl.onerror = null;
                imgEl.style.opacity = '0';
                const parent = imgEl.parentElement;
                if (parent) {
                  const fallback = parent.querySelector('.event-fallback-placeholder') as HTMLElement;
                  if (fallback) fallback.classList.remove('hidden');
                }
              }}
              className="w-full h-full object-cover group-hover/img:scale-105 transition-transform duration-300"
            />
            <div className="event-fallback-placeholder absolute inset-0 hidden flex flex-col items-center justify-center bg-gradient-to-br from-stone-850 to-stone-950 text-amber-400 p-3 text-center pointer-events-none">
              <div className="w-10 h-10 rounded-xl bg-amber-500/15 border border-amber-500/30 flex items-center justify-center mb-1.5 shadow-sm">
                <Sparkles className="w-5 h-5 text-amber-400" />
              </div>
              <span className="text-[11px] font-bold text-stone-300 line-clamp-1">{evt.title}</span>
            </div>
            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover/img:opacity-100 transition-opacity flex items-center justify-center">
              <span className="px-2.5 py-1 rounded-lg bg-black/70 text-white text-[10px] font-bold flex items-center gap-1">
                <Maximize2 className="w-3 h-3" /> Ampliar
              </span>
            </div>
            {evt.badge && (
              <span className="absolute top-2 left-2 px-2 py-0.5 rounded-full bg-amber-500 text-stone-950 font-bold text-[10px] shadow-sm">
                {evt.badge}
              </span>
            )}
            {evt.aiDetected && (
              <span className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-indigo-600 text-white font-black text-[9px] shadow-sm flex items-center gap-1">
                <Bot className="w-2.5 h-2.5" /> Radar IA
              </span>
            )}
          </div>

        <div className="space-y-1">
          <div className="flex items-center gap-1.5 text-[11px] text-amber-400 font-semibold">
            <span>{evt.category}</span>
            {evt.cost && (
              <>
                <span className="text-stone-600">•</span>
                <span className="text-stone-300">${evt.cost}</span>
              </>
            )}
          </div>
          <h4 className="font-bold text-sm text-white group-hover:text-amber-400 transition-colors line-clamp-2">
            {evt.title}
          </h4>
        </div>

        <div className="space-y-1 text-xs text-stone-400 pt-1 border-t border-stone-800">
          <div className="flex items-center gap-1.5 truncate">
            <Calendar className="w-3.5 h-3.5 text-amber-500 shrink-0" />
            <span className="truncate">{evt.date}</span>
          </div>
          {evt.time && (
            <div className="flex items-center gap-1.5 truncate">
              <Clock className="w-3.5 h-3.5 text-stone-500 shrink-0" />
              <span className="truncate">{evt.time}</span>
            </div>
          )}
          {evt.location && (
            <div className="flex items-center gap-1.5 truncate">
              <MapPin className="w-3.5 h-3.5 text-stone-500 shrink-0" />
              <span className="truncate">{evt.location}</span>
            </div>
          )}
        </div>
      </div>

      <div className="pt-3 mt-2 border-t border-stone-800/80 flex items-center justify-between text-xs">
        <span className="text-[11px] text-amber-500/90 font-medium group-hover:underline">
          Ver detalles
        </span>
        {evt.sourceUrl ? (
          <a
            href={evt.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={e => e.stopPropagation()}
            className="text-[10px] text-sky-400 hover:text-sky-300 font-bold flex items-center gap-1 hover:underline"
            title="Ver fuente oficial de este evento"
          >
            <ExternalLink className="w-2.5 h-2.5" />
            <span>Fuente oficial</span>
          </a>
        ) : evt.organizer ? (
          <span className="text-[10px] text-stone-500 truncate max-w-[120px]">
            {evt.organizer}
          </span>
        ) : null}
      </div>

      {isAdmin && (
        <div className="pt-2 mt-1 border-t border-stone-800/80 flex items-center justify-between gap-1.5" onClick={e => e.stopPropagation()}>
          <button
            type="button"
            onClick={(e) => handleOpenEditEvent(evt, e)}
            className="flex-1 py-1 px-2 rounded-lg bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border border-sky-500/40 text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
            title="Modificar evento"
          >
            <Edit2 className="w-3 h-3" />
            <span>Modificar</span>
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteEvent(evt.id, evt.title);
            }}
            className="flex-1 py-1 px-2 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-200 border border-rose-500/40 text-[11px] font-bold flex items-center justify-center gap-1 transition-all cursor-pointer"
            title="Eliminar evento"
          >
            <Trash2 className="w-3 h-3" />
            <span>Eliminar</span>
          </button>
        </div>
      )}
    </div>
  );
};

  return (
    <section className="w-full max-w-[1560px] mx-auto px-3 sm:px-6 lg:px-8 my-5 text-left">
      <div
        className="bg-gradient-to-r from-stone-900 via-[#14120e] to-stone-900 border border-stone-800/90 rounded-3xl p-4 sm:p-6 text-white shadow-xl relative overflow-hidden space-y-4"
        onMouseEnter={() => setIsHovered(true)}
        onMouseLeave={() => setIsHovered(false)}
      >
        {/* Top Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-stone-800">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-stone-950 font-black text-[10px] tracking-wider uppercase">
                  Cartelera Carmelita
                </span>
                <span className="text-xs text-stone-400">
                  {events.length} evento{events.length === 1 ? '' : 's'} activo{events.length === 1 ? '' : 's'}
                </span>
              </div>
              <h3 className="text-base sm:text-lg font-bold text-white tracking-tight mt-0.5">
                Eventos, Conciertos, Ferias y Bazares en Carmen
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2 self-end sm:self-auto flex-wrap">
            {totalPages > 1 && (
              <div className="flex items-center gap-1.5 bg-stone-800/80 p-1 rounded-xl border border-stone-700">
                <button
                  type="button"
                  onClick={handlePrevPage}
                  className="p-1.5 rounded-lg hover:bg-stone-700 text-stone-300 hover:text-white transition-colors cursor-pointer"
                  title="Página anterior"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <span className="text-xs font-mono px-2 text-stone-300">
                  {currentPage + 1} / {totalPages}
                </span>
                <button
                  type="button"
                  onClick={handleNextPage}
                  className="p-1.5 rounded-lg hover:bg-stone-700 text-stone-300 hover:text-white transition-colors cursor-pointer"
                  title="Página siguiente"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Search Bar & AI Search Button */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2.5">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => setSearchQuery(e.target.value)}
              placeholder="Buscar por nombre, malecón, playa, feria, bazar..."
              className="w-full pl-10 pr-8 py-2.5 bg-stone-900/90 border border-stone-800 rounded-2xl text-xs sm:text-sm text-white placeholder-stone-400 outline-none focus:border-amber-500/70 transition-colors"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-stone-400 hover:text-white cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <button
            type="button"
            onClick={handleAiSearch}
            disabled={isAiSearching}
            className="px-4 py-2.5 rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-purple-600 hover:from-purple-500 hover:to-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-95 border border-purple-400/30 shrink-0 disabled:opacity-50"
            title="Búsqueda avanzada con Inteligencia Artificial (Google Gemini)"
          >
            {isAiSearching ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin text-white" />
                <span>Analizando con IA...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 text-amber-300 animate-pulse" />
                <span>Búsqueda avanzada con IA</span>
              </>
            )}
          </button>
        </div>

        {/* AI Notification Banner */}
        {aiSearchNotification && (
          <div
            className={`p-3 rounded-2xl border text-xs flex items-center gap-2 ${
              aiSearchNotification.type === 'warning'
                ? 'bg-amber-950/60 border-amber-500/40 text-amber-200'
                : aiSearchNotification.type === 'error'
                ? 'bg-rose-950/60 border-rose-500/40 text-rose-200'
                : 'bg-emerald-950/60 border-emerald-500/40 text-emerald-200'
            }`}
          >
            {aiSearchNotification.type === 'warning' ? (
              <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            ) : aiSearchNotification.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            )}
            <span className="flex-1">{aiSearchNotification.text}</span>
            <button
              type="button"
              onClick={() => setAiSearchNotification(null)}
              className="text-stone-400 hover:text-white cursor-pointer"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Category Pills */}
        {categories.length > 1 && (
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {categories.map(cat => (
              <button
                key={cat.slug}
                type="button"
                onClick={() => setSelectedCategory(cat.slug)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === cat.slug
                    ? 'bg-amber-500 text-stone-950 shadow-sm'
                    : 'bg-stone-850/80 hover:bg-stone-800 text-stone-300 border border-stone-800'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}

        {/* Carousel / Page Grid */}
        {filteredEvents.length === 0 ? (
          <div className="py-10 text-center text-stone-400 text-xs">
            No hay eventos en esta categoría por el momento.
          </div>
        ) : (
          <div className="relative overflow-hidden">
            {/* If 4 or fewer items, show directly in a clean 4-column grid with NO sliding */}
            {filteredEvents.length <= 4 ? (
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {filteredEvents.map(evt => renderEventCard(evt))}
              </div>
            ) : (
              /* If more than 4 items, paginated carousel sliding 1 full page (4 items) */
              <div
                className="flex transition-transform duration-700 ease-out"
                style={{ transform: `translateX(-${currentPage * 100}%)` }}
              >
                {Array.from({ length: totalPages }).map((_, pageIdx) => {
                  const pageItems = filteredEvents.slice(
                    pageIdx * itemsPerPage,
                    (pageIdx + 1) * itemsPerPage
                  );
                  return (
                    <div
                      key={pageIdx}
                      className="w-full shrink-0 grid grid-cols-1 md:grid-cols-4 gap-4"
                    >
                      {pageItems.map(evt => renderEventCard(evt))}
                    </div>
                  );
                })}
              </div>
            )}

            {/* Indicadores de puntos por página */}
            {totalPages > 1 && (
              <div className="flex items-center justify-center gap-1.5 pt-3">
                {Array.from({ length: totalPages }).map((_, idx) => (
                  <button
                    key={idx}
                    onClick={() => setCurrentPage(idx)}
                    className={`h-1.5 rounded-full transition-all cursor-pointer ${
                      currentPage === idx
                        ? 'w-6 bg-amber-500'
                        : 'w-1.5 bg-stone-700 hover:bg-stone-500'
                    }`}
                    title={`Ir a la página ${idx + 1}`}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/70 backdrop-blur-sm">
          <div className="relative w-full max-w-lg bg-stone-900 border border-stone-800 rounded-3xl p-5 sm:p-6 text-white space-y-4 shadow-2xl overflow-hidden my-auto">
            <div className="flex items-center justify-between pb-3 border-b border-stone-800">
              <span className="px-2.5 py-0.5 rounded-full bg-amber-500 text-stone-950 font-bold text-xs">
                {selectedEvent.category}
              </span>
              <button
                onClick={() => setSelectedEvent(null)}
                className="p-1.5 rounded-full hover:bg-stone-800 text-stone-400 hover:text-white transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {selectedEvent && (
              <div
                onClick={() => {
                  const mImg = getEventRepresentativeImage(selectedEvent);
                  setLightboxImage({ url: mImg, title: selectedEvent.title });
                }}
                className="h-56 w-full rounded-2xl overflow-hidden border border-stone-800 cursor-pointer group"
              >
                <img
                  src={getEventRepresentativeImage(selectedEvent)}
                  alt={selectedEvent.title}
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    const imgEl = e.currentTarget as HTMLImageElement;
                    imgEl.onerror = null;
                    imgEl.src = getEventRepresentativeImage(selectedEvent);
                  }}
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                />
              </div>
            )}

            <div className="space-y-2">
              <h3 className="text-xl font-black text-white">{selectedEvent.title}</h3>
              <p className="text-xs text-stone-300 leading-relaxed whitespace-pre-line">
                {selectedEvent.description}
              </p>
            </div>

            <div className="p-3.5 rounded-xl bg-stone-800/80 border border-stone-700/60 space-y-2 text-xs text-stone-300">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Fecha: {selectedEvent.date}</span>
              </div>
              {selectedEvent.time && (
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Horario: {selectedEvent.time}</span>
                </div>
              )}
              {selectedEvent.location && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Lugar: {selectedEvent.location}</span>
                </div>
              )}
              {selectedEvent.cost && (
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Costo: ${selectedEvent.cost}</span>
                </div>
              )}
              {selectedEvent.organizer && (
                <div className="flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-amber-500 shrink-0" />
                  <span>Organizador: {selectedEvent.organizer}</span>
                </div>
              )}
              {selectedEvent.sourceUrl && (
                <div className="pt-2 mt-1 border-t border-stone-700 flex items-center justify-between gap-2">
                  <span className="flex items-center gap-1.5 text-stone-400">
                    <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
                    <span>Fuente / Enlace oficial:</span>
                  </span>
                  <a
                    href={selectedEvent.sourceUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-amber-400 hover:text-amber-300 font-bold underline flex items-center gap-1"
                  >
                    <span>Ver sitio o fuente</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              )}
            </div>

            {isAdmin && (
              <div className="pt-3 border-t border-stone-800 flex items-center justify-between gap-2 flex-wrap">
                <span className="text-[11px] text-stone-400 font-bold flex items-center gap-1.5">
                  {selectedEvent.aiDetected ? (
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-400/40 flex items-center gap-1">
                      <Bot className="w-3 h-3 text-indigo-300" />
                      Radar IA (Publicado Automático)
                    </span>
                  ) : (
                    <span>Evento de cartelera</span>
                  )}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => {
                      const evtToEdit = selectedEvent;
                      handleOpenEditEvent(evtToEdit);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-sky-500/20 hover:bg-sky-500/30 text-sky-200 border border-sky-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Modificar este evento"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                    <span>Modificar</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      handleDeleteEvent(selectedEvent.id, selectedEvent.title);
                    }}
                    className="px-3.5 py-1.5 rounded-xl bg-rose-500/20 hover:bg-rose-500/30 text-rose-300 border border-rose-500/40 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition-colors"
                    title="Eliminar este evento de la cartelera"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Eliminar</span>
                  </button>
                </div>
              </div>
            )}

            <div className="flex justify-end pt-2">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-5 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-white font-bold text-xs cursor-pointer"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Quick Edit Modal for Admins */}
      {isEditorOpen && editingEvent && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/80 backdrop-blur-xs animate-fadeIn">
          <div className="bg-stone-900 border border-stone-700 rounded-3xl max-w-lg w-full p-5 sm:p-6 text-white shadow-2xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-800 pb-3">
              <div className="flex items-center gap-2">
                <span className="p-2 rounded-xl bg-amber-500/20 text-amber-400">
                  <Edit2 className="w-4 h-4" />
                </span>
                <div>
                  <h3 className="text-sm sm:text-base font-bold text-white">
                    Modificar Evento de Cartelera
                  </h3>
                  <p className="text-[11px] text-stone-400">
                    Cambios guardados en vivo para todos los visitantes
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  setIsEditorOpen(false);
                  setEditingEvent(null);
                }}
                className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEvent} className="space-y-3 text-xs">
              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Título del Evento *
                </label>
                <input
                  type="text"
                  required
                  value={eventForm.title}
                  onChange={e => setEventForm(prev => ({ ...prev, title: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  placeholder="ej. Gran Concierto Tropical"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Categoría
                  </label>
                  <select
                    value={eventForm.category}
                    onChange={e => {
                      const val = e.target.value;
                      let slug = 'cultura';
                      if (val.includes('Bazar') || val.includes('Emprend')) slug = 'bazares';
                      else if (val.includes('Mús') || val.includes('Conc')) slug = 'cultura';
                      else if (val.includes('Depor') || val.includes('Rod')) slug = 'deportes';
                      else if (val.includes('Gastro')) slug = 'gastronomia';
                      else if (val.includes('Feria') || val.includes('Expo')) slug = 'ferias';
                      setEventForm(prev => ({ ...prev, category: val, categorySlug: slug }));
                    }}
                    className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white focus:outline-none focus:border-amber-500 cursor-pointer"
                  >
                    <option value="Cultura & Música">Cultura & Música</option>
                    <option value="Ferias, Exposiciones y Tradición">Ferias, Exposiciones y Tradición</option>
                    <option value="Deportes">Deportes</option>
                    <option value="Bazares y Emprendedores">Bazares y Emprendedores</option>
                    <option value="Gastronomía">Gastronomía</option>
                  </select>
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Costo de Entrada
                  </label>
                  <input
                    type="text"
                    value={eventForm.cost}
                    onChange={e => setEventForm(prev => ({ ...prev, cost: e.target.value }))}
                    className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                    placeholder="ej. Entrada Libre o $100 MXN"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Fecha
                  </label>
                  <input
                    type="text"
                    value={eventForm.date}
                    onChange={e => setEventForm(prev => ({ ...prev, date: e.target.value }))}
                    className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                    placeholder="ej. Sábado 25 de Octubre"
                  />
                </div>

                <div>
                  <label className="block text-stone-300 font-semibold mb-1">
                    Horario
                  </label>
                  <input
                    type="text"
                    value={eventForm.time}
                    onChange={e => setEventForm(prev => ({ ...prev, time: e.target.value }))}
                    className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                    placeholder="ej. 6:00 PM a 11:00 PM"
                  />
                </div>
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Lugar o Recinto *
                </label>
                <input
                  type="text"
                  required
                  value={eventForm.location}
                  onChange={e => setEventForm(prev => ({ ...prev, location: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  placeholder="ej. Playa Norte, Ciudad del Carmen"
                />
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Organizador / Patrocinador
                </label>
                <input
                  type="text"
                  value={eventForm.organizer}
                  onChange={e => setEventForm(prev => ({ ...prev, organizer: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  placeholder="ej. DIF Carmen / Colectivo Local"
                />
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Descripción
                </label>
                <textarea
                  rows={3}
                  value={eventForm.description}
                  onChange={e => setEventForm(prev => ({ ...prev, description: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500 resize-none"
                  placeholder="Detalles sobre las actividades, artistas o programa..."
                />
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  URL de Imagen del Evento (opcional)
                </label>
                <input
                  type="url"
                  value={eventForm.image}
                  onChange={e => setEventForm(prev => ({ ...prev, image: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  placeholder="https://images.unsplash.com/..."
                />
              </div>

              <div>
                <label className="block text-stone-300 font-semibold mb-1">
                  Enlace de Fuente Oficial / Referencia Web (opcional)
                </label>
                <input
                  type="url"
                  value={eventForm.sourceUrl || ''}
                  onChange={e => setEventForm(prev => ({ ...prev, sourceUrl: e.target.value }))}
                  className="w-full px-3 py-2 bg-stone-800 border border-stone-700 rounded-xl text-white placeholder:text-stone-500 focus:outline-none focus:border-amber-500"
                  placeholder="https://..."
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-800">
                <button
                  type="button"
                  onClick={() => {
                    setIsEditorOpen(false);
                    setEditingEvent(null);
                  }}
                  className="px-4 py-2 rounded-xl bg-stone-800 hover:bg-stone-700 text-stone-300 font-semibold transition-colors cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-black transition-all shadow-lg shadow-amber-500/20 cursor-pointer active:scale-95"
                >
                  Guardar Cambios
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Lightbox for Event Image */}
      {lightboxImage && (
        <div
          onClick={() => setLightboxImage(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md cursor-pointer"
        >
          <div className="relative max-w-3xl max-h-[90vh] overflow-hidden rounded-2xl">
            <img
              src={lightboxImage.url}
              alt={lightboxImage.title}
              className="max-h-[85vh] w-auto object-contain rounded-2xl"
            />
            <button
              onClick={() => setLightboxImage(null)}
              className="absolute top-3 right-3 p-2 rounded-full bg-black/60 text-white hover:bg-black/90 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
