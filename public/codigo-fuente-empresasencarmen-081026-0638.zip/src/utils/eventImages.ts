/**
 * Smart representative image resolver for events in Ciudad del Carmen.
 * Analyzes event title, description, category, and location to provide
 * vibrant, relevant, high-definition photography when no photo is attached.
 */

export const THEMATIC_EVENT_IMAGES = {
  // 1. Carreras, Maratones, Atletismo, 5K, 10K, Octubre Rosa
  running: 'https://images.unsplash.com/photo-1552674605-db6ffd4facb5?w=800&auto=format&fit=crop&q=80',
  // 2. Ciclismo, Rodadas
  cycling: 'https://images.unsplash.com/photo-1541625602330-2277a4c46182?w=800&auto=format&fit=crop&q=80',
  // 3. Fútbol / Soccer
  soccer: 'https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&auto=format&fit=crop&q=80',
  // 4. Béisbol / Softbol
  baseball: 'https://images.unsplash.com/photo-1508344928928-7165b67de128?w=800&auto=format&fit=crop&q=80',
  // 5. Pesca deportiva / Torneo de pesca / Marítimo
  fishing: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&auto=format&fit=crop&q=80',
  // 6. Fitness / Gimnasio / Crossfit / Deportes varios
  sportsGeneral: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800&auto=format&fit=crop&q=80',
  // 7. Congresos / Conferencias / Convenciones / Carmen XXI / Foros / Negocios
  conference: 'https://images.unsplash.com/photo-1511578314322-379afb476865?w=800&auto=format&fit=crop&q=80',
  // 8. Agroindustria / Campo / Agrícola / Productos de Campeche
  agriculture: 'https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800&auto=format&fit=crop&q=80',
  // 9. Conciertos en vivo / Rock / Pop / Bandas
  concert: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?w=800&auto=format&fit=crop&q=80',
  // 10. Fiesta nocturna / DJ / Electrónica
  partyNight: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=800&auto=format&fit=crop&q=80',
  // 11. Danzón / Boleros / Marimba / Tradición Carmelita / Parque Zaragoza
  tradicionZaragoza: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7?w=800&auto=format&fit=crop&q=80',
  // 12. Bazares / Emprendedores / Expo Eventia / Mercaditos
  bazar: 'https://images.unsplash.com/photo-1533900298318-6b8da08a523e?w=800&auto=format&fit=crop&q=80',
  // 13. Festival Gastronómico / Mariscos / Camarón
  gastronomiaMariscos: 'https://images.unsplash.com/photo-1559847844-5315695dadae?w=800&auto=format&fit=crop&q=80',
  // 14. Parrilladas / Carnes / Asados / BBQ
  grill: 'https://images.unsplash.com/photo-1555939594-58d7cb561ad1?w=800&auto=format&fit=crop&q=80',
  // 15. Café / Repostería / Panadería
  bakeryCafe: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?w=800&auto=format&fit=crop&q=80',
  // 16. Día de Muertos / Hanal Pixán / Catrinas / Calaveras
  diaDeMuertos: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=800&auto=format&fit=crop&q=80',
  // 17. Teatro / Artes Escénicas / Comedia / Stand Up
  theater: 'https://images.unsplash.com/photo-1507676184212-d03ab07a01bf?w=800&auto=format&fit=crop&q=80',
  // 18. Danza / Baile folclórico / Ballet / Jarana
  dance: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?w=800&auto=format&fit=crop&q=80',
  // 19. Cine / Películas / Cine al aire libre
  cinema: 'https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800&auto=format&fit=crop&q=80',
  // 20. Exposiciones de Arte / Pintura / Galerías
  artExhibition: 'https://images.unsplash.com/photo-1536924940846-227afb31e2a5?w=800&auto=format&fit=crop&q=80',
  // 21. Infantil / Niños / Familia / Shows
  kidsFamily: 'https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=800&auto=format&fit=crop&q=80',
  // 22. Mascotas / Perrotón / Adopción canina
  pets: 'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800&auto=format&fit=crop&q=80',
  // 23. Playa Norte / Malecón / Festival playero
  beach: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=800&auto=format&fit=crop&q=80',
  // 24. Fiestas Patronales / Virgen del Carmen / Procesión
  patronalFiesta: 'https://images.unsplash.com/photo-1518638150340-f706e86654de?w=800&auto=format&fit=crop&q=80',
  // 25. Yoga / Salud / Bienestar
  wellness: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?w=800&auto=format&fit=crop&q=80',
  defaultEvent: 'https://images.unsplash.com/photo-1492684223066-81342ee5ff30?w=800&auto=format&fit=crop&q=80'
};

export function getEventRepresentativeImage(event: {
  title?: string;
  category?: string;
  categorySlug?: string;
  description?: string;
  location?: string;
  image?: string;
}): string {
  // If image is already a full remote HTTPS URL, return it
  if (event.image && typeof event.image === 'string' && event.image.startsWith('http')) {
    return event.image.trim();
  }

  // If image is a legacy relative upload, map known placeholders to permanent HTTPS URLs
  if (event.image && typeof event.image === 'string') {
    const raw = event.image.trim();
    if (raw.includes('dia-de-muertos')) return THEMATIC_EVENT_IMAGES.diaDeMuertos;
    if (raw.includes('kiosco-parque-zaragoza')) return THEMATIC_EVENT_IMAGES.tradicionZaragoza;
    if (raw.includes('bazar-emprendedores')) return THEMATIC_EVENT_IMAGES.bazar;
    if (raw.includes('festival-gastronomico')) return THEMATIC_EVENT_IMAGES.gastronomiaMariscos;
    if (raw.includes('concierto-musica')) return THEMATIC_EVENT_IMAGES.concert;
  }

  const text = `${event.title || ''} ${event.description || ''} ${event.category || ''} ${event.location || ''}`.toLowerCase();

  // 1. Día de Muertos / Tradiciones de Muertos / Catrinas / Hanal Pixán
  if (
    text.includes('muerto') ||
    text.includes('catrina') ||
    text.includes('cempasúchil') ||
    text.includes('cempasuchil') ||
    text.includes('ánima') ||
    text.includes('anima') ||
    text.includes('altar') ||
    text.includes('calaver') ||
    text.includes('hanal pix') ||
    text.includes('hallow')
  ) {
    return THEMATIC_EVENT_IMAGES.diaDeMuertos;
  }

  // 2. Agroindustria / Congreso Agroindustrial / Campo / Productos de Campeche
  if (
    text.includes('agroindustrial') ||
    text.includes('agro') ||
    text.includes('agrícol') ||
    text.includes('agricol') ||
    text.includes('campo') ||
    text.includes('siembra') ||
    text.includes('ganader') ||
    text.includes('cosecha') ||
    text.includes('productos de campeche')
  ) {
    return THEMATIC_EVENT_IMAGES.agriculture;
  }

  // 3. Carreras, Maratones, 5K, 10K, Atletismo, Octubre Rosa
  if (
    text.includes('carrera') ||
    text.includes('maratón') ||
    text.includes('maraton') ||
    text.includes('5k') ||
    text.includes('10k') ||
    text.includes('21k') ||
    text.includes('atlet') ||
    text.includes('corredor') ||
    text.includes('running') ||
    text.includes('octubre rosa') ||
    text.includes('cáncer de mama')
  ) {
    return THEMATIC_EVENT_IMAGES.running;
  }

  // 4. Ciclismo / Rodadas / Bicicleta
  if (
    text.includes('rodada') ||
    text.includes('ciclis') ||
    text.includes('bicicleta') ||
    text.includes('bici')
  ) {
    return THEMATIC_EVENT_IMAGES.cycling;
  }

  // 5. Pesca / Torneo de Pesca / Sábalo / Marítimo
  if (
    text.includes('pesca') ||
    text.includes('sábalo') ||
    text.includes('sabalo') ||
    text.includes('anzuelo') ||
    text.includes('lancha')
  ) {
    return THEMATIC_EVENT_IMAGES.fishing;
  }

  // 6. Fútbol / Soccer
  if (
    text.includes('fútbol') ||
    text.includes('futbol') ||
    text.includes('soccer') ||
    text.includes('gol')
  ) {
    return THEMATIC_EVENT_IMAGES.soccer;
  }

  // 7. Béisbol / Softbol
  if (
    text.includes('béisbol') ||
    text.includes('beisbol') ||
    text.includes('softbol') ||
    text.includes('pelota') ||
    text.includes('jonrón') ||
    text.includes('resineros')
  ) {
    return THEMATIC_EVENT_IMAGES.baseball;
  }

  // 8. Congresos / Convenciones / Carmen XXI / Foros / Cumbres / Negocios / Simposio
  if (
    text.includes('congreso') ||
    text.includes('convención') ||
    text.includes('convencion') ||
    text.includes('carmen xxi') ||
    text.includes('foro') ||
    text.includes('cumbre') ||
    text.includes('simposio') ||
    text.includes('conferencia') ||
    text.includes('panel') ||
    text.includes('empresarial') ||
    text.includes('negocios')
  ) {
    return THEMATIC_EVENT_IMAGES.conference;
  }

  // 9. Teatro / Artes Escénicas / Monólogo / Stand Up / Comedia
  if (
    text.includes('teatro') ||
    text.includes('obra') ||
    text.includes('monólogo') ||
    text.includes('monologo') ||
    text.includes('stand up') ||
    text.includes('comedia') ||
    text.includes('dramat') ||
    text.includes('escena') ||
    text.includes('teatro carmelita')
  ) {
    return THEMATIC_EVENT_IMAGES.theater;
  }

  // 10. Danza / Baile / Folclor / Ballet / Jarana
  if (
    text.includes('danza') ||
    text.includes('baile') ||
    text.includes('ballet') ||
    text.includes('folclor') ||
    text.includes('jarana') ||
    text.includes('coreograf')
  ) {
    return THEMATIC_EVENT_IMAGES.dance;
  }

  // 11. Cine / Películas / Proyección al aire libre
  if (
    text.includes('cine') ||
    text.includes('película') ||
    text.includes('pelicula') ||
    text.includes('cortometraje') ||
    text.includes('film') ||
    text.includes('proyección') ||
    text.includes('proyeccion')
  ) {
    return THEMATIC_EVENT_IMAGES.cinema;
  }

  // 12. Arte / Pintura / Galerías / Exposiciones Plásticas
  if (
    text.includes('exposición') ||
    text.includes('exposicion') ||
    text.includes('galería') ||
    text.includes('galeria') ||
    text.includes('pintura') ||
    text.includes('escultura') ||
    text.includes('fotografía') ||
    text.includes('fotografia') ||
    text.includes('artes plásticas')
  ) {
    return THEMATIC_EVENT_IMAGES.artExhibition;
  }

  // 13. Kiosco Zaragoza / Danzón / Marimba / Boleros / Tradición Carmelita
  if (
    text.includes('kiosco') ||
    text.includes('zaragoza') ||
    text.includes('parque principal') ||
    text.includes('bolero') ||
    text.includes('danzón') ||
    text.includes('danzon') ||
    text.includes('marimba') ||
    text.includes('son campechano') ||
    text.includes('trova') ||
    text.includes('campechanidad') ||
    text.includes('desfile cultural')
  ) {
    return THEMATIC_EVENT_IMAGES.tradicionZaragoza;
  }

  // 14. Gastronomía marina / Camarón / Mariscos / Pescados / Ceviche
  if (
    text.includes('camarón') ||
    text.includes('camaron') ||
    text.includes('marisco') ||
    text.includes('gastronom') ||
    text.includes('culinari') ||
    text.includes('platillo') ||
    text.includes('degustac') ||
    text.includes('chef') ||
    text.includes('ceviche') ||
    text.includes('coctel')
  ) {
    return THEMATIC_EVENT_IMAGES.gastronomiaMariscos;
  }

  // 15. Parrillada / Asados / BBQ / Carnes
  if (
    text.includes('asado') ||
    text.includes('parrill') ||
    text.includes('bbq') ||
    text.includes('carne')
  ) {
    return THEMATIC_EVENT_IMAGES.grill;
  }

  // 16. Café / Repostería / Panadería / Postres
  if (
    text.includes('café') ||
    text.includes('cafe') ||
    text.includes('reposter') ||
    text.includes('postre') ||
    text.includes('panader')
  ) {
    return THEMATIC_EVENT_IMAGES.bakeryCafe;
  }

  // 17. Conciertos / Música en Vivo / Rock / Pop / Bandas
  if (
    text.includes('concierto') ||
    text.includes('música') ||
    text.includes('musica') ||
    text.includes('en vivo') ||
    text.includes('tributo') ||
    text.includes('rock') ||
    text.includes('banda') ||
    text.includes('guitarra') ||
    text.includes('acústic') ||
    text.includes('acustic') ||
    text.includes('recital') ||
    text.includes('jazz') ||
    text.includes('canto') ||
    text.includes('show') ||
    text.includes('blnko') ||
    text.includes('austin') ||
    text.includes('revo') ||
    text.includes('cantautor')
  ) {
    return THEMATIC_EVENT_IMAGES.concert;
  }

  // 18. Fiestas nocturnas / DJ / Electrónica
  if (
    text.includes('dj') ||
    text.includes('electrónica') ||
    text.includes('fiesta nocturna') ||
    text.includes('antro') ||
    text.includes('club')
  ) {
    return THEMATIC_EVENT_IMAGES.partyNight;
  }

  // 19. Bazares / Emprendedores / Mercaditos / Expo Eventia / Artesanías
  if (
    text.includes('bazar') ||
    text.includes('placita') ||
    text.includes('emprended') ||
    text.includes('artesan') ||
    text.includes('mercadito') ||
    text.includes('expo eventia') ||
    text.includes('tianguis') ||
    text.includes('comercial')
  ) {
    return THEMATIC_EVENT_IMAGES.bazar;
  }

  // 20. Fiestas Patronales / Virgen del Carmen / Procesión
  if (
    text.includes('virgen del carmen') ||
    text.includes('patronal') ||
    text.includes('procesión') ||
    text.includes('procesion') ||
    text.includes('paseo por mar')
  ) {
    return THEMATIC_EVENT_IMAGES.patronalFiesta;
  }

  // 21. Playa Norte / Malecón / Eventos costeros
  if (
    text.includes('playa norte') ||
    text.includes('playa') ||
    text.includes('malecón') ||
    text.includes('malecon') ||
    text.includes('costero')
  ) {
    return THEMATIC_EVENT_IMAGES.beach;
  }

  // 22. Niños / Infantil / Familia
  if (
    text.includes('infantil') ||
    text.includes('niño') ||
    text.includes('niña') ||
    text.includes('títeres') ||
    text.includes('titeres') ||
    text.includes('marioneta') ||
    text.includes('familiar')
  ) {
    return THEMATIC_EVENT_IMAGES.kidsFamily;
  }

  // 23. Mascotas / Perrotón
  if (
    text.includes('mascota') ||
    text.includes('canin') ||
    text.includes('perro') ||
    text.includes('adopci')
  ) {
    return THEMATIC_EVENT_IMAGES.pets;
  }

  // 24. Yoga / Salud / Bienestar
  if (
    text.includes('yoga') ||
    text.includes('meditac') ||
    text.includes('salud') ||
    text.includes('bienestar')
  ) {
    return THEMATIC_EVENT_IMAGES.wellness;
  }

  // 25. Deportes general
  if (
    text.includes('deport') ||
    text.includes('torneo') ||
    text.includes('campeonato')
  ) {
    return THEMATIC_EVENT_IMAGES.sportsGeneral;
  }

  // Fallbacks by category
  const cat = (event.categorySlug || event.category || '').toLowerCase();
  if (cat.includes('bazar')) return THEMATIC_EVENT_IMAGES.bazar;
  if (cat.includes('gastronom')) return THEMATIC_EVENT_IMAGES.gastronomiaMariscos;
  if (cat.includes('deport')) return THEMATIC_EVENT_IMAGES.sportsGeneral;
  if (cat.includes('música') || cat.includes('musica')) return THEMATIC_EVENT_IMAGES.concert;
  if (cat.includes('cultur') || cat.includes('feria')) return THEMATIC_EVENT_IMAGES.tradicionZaragoza;

  return THEMATIC_EVENT_IMAGES.tradicionZaragoza;
}
