import fs from 'fs';
import path from 'path';

const seedPath = path.resolve('./src/data/businesses_seed.json');
const businesses = JSON.parse(fs.readFileSync(seedPath, 'utf8'));

const forbiddenCombos = [
  { has: 'Aplicación de Uñas y Pestañas', forbidden: ['Alimentos y Bebidas', 'Carnicería'] },
  { has: 'Cuidado y Belleza Personal', forbidden: ['Alimentos y Bebidas', 'Carnicería'] }
];

const toFix = [];

for (const b of businesses) {
  let needsFix = false;
  for (const combo of forbiddenCombos) {
    if (b.categories.includes(combo.has)) {
      for (const forbidden of combo.forbidden) {
        if (b.categories.includes(forbidden)) {
          needsFix = true;
          console.log(`Fixing ${b.name} (ID ${b.id}): Removing ${forbidden} because it has ${combo.has}`);
          b.categories = b.categories.filter((c: string) => c !== forbidden);
          b.categorySlugs = b.categorySlugs.filter((s: string) => !s.includes(forbidden.toLowerCase().replace(/ /g, '-')));
        }
      }
    }
  }
}

fs.writeFileSync(seedPath, JSON.stringify(businesses, null, 2));
console.log('Fix applied.');
