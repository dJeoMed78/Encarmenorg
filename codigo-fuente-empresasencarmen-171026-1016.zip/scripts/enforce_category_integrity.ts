import fs from 'fs';
import path from 'path';

const seedPath = path.resolve('./src/data/businesses_seed.json');
const catPath = path.resolve('./src/data/categories_seed.json');

const businesses = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
const categories = JSON.parse(fs.readFileSync(catPath, 'utf8'));

// Build hierarchy
const slugToParent = new Map();
const idToCategory = new Map();
categories.forEach(c => idToCategory.set(c.id, c));

// Function to get top parent
function getTopParentId(catName) {
  const cat = categories.find(c => c.name === catName);
  if (!cat) return null;
  if (cat.parent === 0) return cat.id;
  
  // Find top
  let current = cat;
  while (current && current.parent !== 0) {
    current = idToCategory.get(current.parent);
  }
  return current ? current.id : null;
}

const FORBIDDEN_MIXES = [
  [62, 374], // Alimentos vs Belleza
  [62, 390], // Alimentos vs Industrial
  [374, 390], // Belleza vs Industrial
];

let modifiedCount = 0;

for (const b of businesses) {
  const parentIds = new Set();
  b.categories.forEach(catName => {
    const topId = getTopParentId(catName);
    if (topId) parentIds.add(topId);
  });

  // Check for forbidden mixes
  let hasForbidden = false;
  for (const mix of FORBIDDEN_MIXES) {
    if (parentIds.has(mix[0]) && parentIds.has(mix[1])) {
      console.log(`Forbidden mix detected in ${b.name} (ID ${b.id}): ${Array.from(parentIds)}`);
      hasForbidden = true;
      // Heuristic: remove the one that isn't the main/first category
      // Or just remove the one with lower count?
      // For now, let's just log and remove the second one in the mix
      b.categories = b.categories.filter(c => getTopParentId(c) !== mix[1]);
      b.categorySlugs = b.categorySlugs.filter(s => {
          const cat = categories.find(c => c.slug === s);
          return !cat || getTopParentId(cat.name) !== mix[1];
      });
      modifiedCount++;
      break;
    }
  }
}

fs.writeFileSync(seedPath, JSON.stringify(businesses, null, 2));
console.log(`Data cleaned. Modified ${modifiedCount} businesses.`);
