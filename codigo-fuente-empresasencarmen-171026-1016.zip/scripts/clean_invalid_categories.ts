import fs from 'fs';
import path from 'path';

const seedPath = path.resolve('./src/data/businesses_seed.json');
const catPath = path.resolve('./src/data/categories_seed.json');

const businesses = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
const categories = JSON.parse(fs.readFileSync(catPath, 'utf8'));

const slugToId = new Map(categories.map(c => [c.slug, c.id]));
const idToCat = new Map(categories.map(c => [c.id, c]));

// Function to get category by slug safely
function getCategoryBySlug(slug) {
  return categories.find(c => c.slug === slug);
}

let modifiedCount = 0;

let needsFix = false;
for (const b of businesses) {
  const originalSlugs = [...b.categorySlugs];
  
  // Keep only category slugs that actually exist in the categories list
  const validSlugs = originalSlugs.filter(slug => getCategoryBySlug(slug));
  
  if (validSlugs.length !== originalSlugs.length) {
    console.log(`Fixing ${b.name} (ID ${b.id}): Invalid slugs removed.`);
    b.categorySlugs = validSlugs;
    b.categories = validSlugs.map(s => getCategoryBySlug(s).name);
    needsFix = true;
    modifiedCount++;
  }
}

if (needsFix || modifiedCount > 0) {
    fs.writeFileSync(seedPath, JSON.stringify(businesses, null, 2));
    console.log(`Data cleaned. Modified ${modifiedCount} businesses.`);
} else {
    console.log('No invalid categories found.');
}
