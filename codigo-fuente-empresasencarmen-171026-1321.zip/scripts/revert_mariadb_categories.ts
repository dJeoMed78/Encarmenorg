import fs from 'fs';
import path from 'path';
import { initMariaDb, dbLoadAllBusinesses, dbSaveBusiness } from '../src/db/mariadb';

async function revert() {
  console.log('Connecting to Hostinger MariaDB...');
  const connected = await initMariaDb();
  if (!connected) {
    console.error('Failed to connect to MariaDB.');
    process.exit(1);
  }

  const dbList = await dbLoadAllBusinesses();
  console.log(`Loaded ${dbList.length} businesses from Hostinger MariaDB.`);

  // Load original seed to restore from
  const seedPath = path.resolve('./src/data/businesses_seed.json');
  const originalSeed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
  const originalMap = new Map(originalSeed.map(b => [Number(b.id), b]));

  let updatedCount = 0;
  for (const b of dbList) {
    const original = originalMap.get(Number(b.id));
    if (original) {
        // Revert to original data
        b.categories = original.categories;
        b.categorySlugs = original.categorySlugs;
        b.category = original.category;
        b.updatedAt = new Date().toISOString();
        await dbSaveBusiness(b);
        updatedCount++;
    }
  }

  console.log(`Successfully reverted ${updatedCount} businesses in Hostinger MariaDB.`);
  process.exit(0);
}

revert().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
