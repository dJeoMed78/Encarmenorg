import { initMariaDb, dbLoadAllBusinesses, dbSaveBusiness } from '../src/db/mariadb';
import fs from 'fs';
import path from 'path';

const fixes: Record<number, { categories: string[]; categorySlugs: string[]; category: string }> = {
  // Industrial & Safety
  3519: {
    categories: ['Sector Industrial, Petrolero y Construcción', 'Seguridad Industrial y Equipo de Protección (EPP)'],
    categorySlugs: ['sector-industrial-petrolero-y-construccion', 'seguridad-industrial-y-equipo-de-proteccion-epp'],
    category: 'Seguridad Industrial y Equipo de Protección (EPP)'
  },
  // Butcher shops & Food
  1588: {
    categories: ['Alimentos y Bebidas', 'Comercio y Distribución de alimentos'],
    categorySlugs: ['alimentos-y-bebidas', 'comercio-y-distribucion-de-alimentos'],
    category: 'Comercio y Distribución de alimentos'
  },
  1951: {
    categories: ['Alimentos y Bebidas', 'Comercio y Distribución de alimentos'],
    categorySlugs: ['alimentos-y-bebidas', 'comercio-y-distribucion-de-alimentos'],
    category: 'Comercio y Distribución de alimentos'
  },
  2042: {
    categories: ['Alimentos y Bebidas', 'Comercio y Distribución de alimentos'],
    categorySlugs: ['alimentos-y-bebidas', 'comercio-y-distribucion-de-alimentos'],
    category: 'Comercio y Distribución de alimentos'
  },
  1242: {
    categories: ['Alimentos y Bebidas', 'Cafeterías, Jugos y Postres'],
    categorySlugs: ['alimentos-y-bebidas', 'cafeterias-jugos-y-postres'],
    category: 'Cafeterías, Jugos y Postres'
  },
  // Printing & Advertising
  1417: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Imprentas, Publicidad y Rotulación'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'imprentas-publicidad-y-rotulacion'],
    category: 'Imprentas, Publicidad y Rotulación'
  },
  // Hair & Aesthetics (not nails)
  1463: {
    categories: ['Cuidado y Belleza Personal', 'Estéticas y Belleza Femenina'],
    categorySlugs: ['cuidado-y-belleza-personal', 'esteticas-y-belleza-femenina'],
    category: 'Estéticas y Belleza Femenina'
  },
  1503: {
    categories: ['Cuidado y Belleza Personal', 'Cosméticos, Perfumería y Joyería'],
    categorySlugs: ['cuidado-y-belleza-personal', 'cosmeticos-perfumeria-y-joyeria'],
    category: 'Cosméticos, Perfumería y Joyería'
  },
  1507: {
    categories: ['Cuidado y Belleza Personal', 'Estéticas y Belleza Femenina'],
    categorySlugs: ['cuidado-y-belleza-personal', 'esteticas-y-belleza-femenina'],
    category: 'Estéticas y Belleza Femenina'
  },
  1311: {
    categories: ['Cuidado y Belleza Personal', 'Estéticas y Belleza Femenina'],
    categorySlugs: ['cuidado-y-belleza-personal', 'esteticas-y-belleza-femenina'],
    category: 'Estéticas y Belleza Femenina'
  },
  2374: {
    categories: ['Cuidado y Belleza Personal', 'Barberías y Peluquerías'],
    categorySlugs: ['cuidado-y-belleza-personal', 'barberias-y-peluquerias'],
    category: 'Barberías y Peluquerías'
  },
  // Martial Arts / Schools
  2387: {
    categories: ['Salud, Bienestar y Educación', 'Psicología, Desarrollo Personal y Escuelas'],
    categorySlugs: ['salud-bienestar-y-educacion', 'psicologia-desarrollo-personal-y-escuelas'],
    category: 'Psicología, Desarrollo Personal y Escuelas'
  },
  // Computer Repair & Tech
  2413: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Venta y Reparación de Celulares y Cómputo'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'venta-y-reparacion-de-celulares-y-computo'],
    category: 'Venta y Reparación de Celulares y Cómputo'
  },
  // Gifts & Novelties
  2633: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Regalos, Florerías y Novedades'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'regalos-florerias-y-novedades'],
    category: 'Regalos, Florerías y Novedades'
  },
  // Fragrances & Jewelry
  2716: {
    categories: ['Cuidado y Belleza Personal', 'Cosméticos, Perfumería y Joyería'],
    categorySlugs: ['cuidado-y-belleza-personal', 'cosmeticos-perfumeria-y-joyeria'],
    category: 'Cosméticos, Perfumería y Joyería'
  },
  // Boutiques & Fashion
  2833: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Boutiques, Ropa y Calzado'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'boutiques-ropa-y-calzado'],
    category: 'Boutiques, Ropa y Calzado'
  },
  2521: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Boutiques, Ropa y Calzado'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'boutiques-ropa-y-calzado'],
    category: 'Boutiques, Ropa y Calzado'
  },
  // Health & Pharmacy
  2868: {
    categories: ['Salud, Bienestar y Educación', 'Herbolaria, Farmacias y Tiendas Naturistas'],
    categorySlugs: ['salud-bienestar-y-educacion', 'herbolaria-farmacias-y-tiendas-naturistas'],
    category: 'Herbolaria, Farmacias y Tiendas Naturistas'
  },
  // Spa & Massages (not nails)
  3241: {
    categories: ['Cuidado y Belleza Personal', 'Masajes, Spa y Tratamientos'],
    categorySlugs: ['cuidado-y-belleza-personal', 'masajes-spa-y-tratamientos'],
    category: 'Masajes, Spa y Tratamientos'
  },
  // Cosmetics store
  3898: {
    categories: ['Cuidado y Belleza Personal', 'Cosméticos, Perfumería y Joyería'],
    categorySlugs: ['cuidado-y-belleza-personal', 'cosmeticos-perfumeria-y-joyeria'],
    category: 'Cosméticos, Perfumería y Joyería'
  }
};

async function run() {
  console.log('Connecting to Hostinger MariaDB...');
  const connected = await initMariaDb();
  if (!connected) {
    console.error('Failed to connect to MariaDB.');
    process.exit(1);
  }

  const dbList = await dbLoadAllBusinesses();
  console.log(`Loaded ${dbList.length} businesses from Hostinger MariaDB.`);

  let updatedCount = 0;
  for (const b of dbList) {
    const fix = fixes[Number(b.id)];
    if (fix) {
      console.log(`Updating [${b.id}] "${b.name}" in MariaDB...`);
      b.categories = fix.categories;
      b.categorySlugs = fix.categorySlugs;
      b.category = fix.category;
      b.updatedAt = new Date().toISOString();
      const ok = await dbSaveBusiness(b);
      if (ok) updatedCount++;
      else console.warn(`Failed to save [${b.id}] to MariaDB`);
    }
  }

  console.log(`Successfully updated ${updatedCount} businesses in Hostinger MariaDB.`);

  // Also update local businesses_seed.json
  const seedPath = path.resolve('./src/data/businesses_seed.json');
  if (fs.existsSync(seedPath)) {
    const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
    for (const b of seed) {
      const fix = fixes[Number(b.id)];
      if (fix) {
        b.categories = fix.categories;
        b.categorySlugs = fix.categorySlugs;
        b.category = fix.category;
        b.updatedAt = new Date().toISOString();
      }
    }
    fs.writeFileSync(seedPath, JSON.stringify(seed, null, 2));
    console.log('Synchronized businesses_seed.json with MariaDB fixes.');
  }

  // Recalculate categories_seed.json counts
  const catPath = path.resolve('./src/data/categories_seed.json');
  if (fs.existsSync(catPath)) {
    const cats = JSON.parse(fs.readFileSync(catPath, 'utf8'));
    for (const c of cats) {
      const slug = c.slug;
      const name = c.name;
      let count = 0;
      for (const b of dbList) {
        const hasSlug = b.categorySlugs && b.categorySlugs.includes(slug);
        const hasName = b.categories && b.categories.includes(name);
        if (hasSlug || hasName) count++;
      }
      c.count = count;
    }
    fs.writeFileSync(catPath, JSON.stringify(cats, null, 2));
    console.log('Recalculated and saved categories_seed.json counts.');
  }

  console.log('Fix complete! Exiting.');
  process.exit(0);
}

run().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
