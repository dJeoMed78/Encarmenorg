import fs from 'fs';
import path from 'path';
import { initMariaDb, dbLoadAllBusinesses, dbSaveBusiness } from '../src/db/mariadb';

const DEFINITIVE_FIXES: Record<number, { categories: string[]; categorySlugs: string[]; category: string }> = {
  // LASHES & NAILS (PHIStudio was misclassified under psychology!)
  1302: {
    categories: ['Cuidado y Belleza Personal', 'Aplicación de Uñas y Pestañas'],
    categorySlugs: ['cuidado-y-belleza-personal', 'aplicacion-de-unas-y-pestanas'],
    category: 'Aplicación de Uñas y Pestañas'
  },
  // LOGISTICS & TRANSPORT (Remove incorrect auto repair / trades tags)
  1148: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  1184: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  1298: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  1390: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  1392: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  1497: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  1499: {
    categories: ['Servicios Logísticos y Transporte', 'Choferes, Taxis y Transporte Privado'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'choferes-taxis-y-transporte-privado'],
    category: 'Choferes, Taxis y Transporte Privado'
  },
  1501: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  1505: {
    categories: ['Servicios Logísticos y Transporte', 'Choferes, Taxis y Transporte Privado'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'choferes-taxis-y-transporte-privado'],
    category: 'Choferes, Taxis y Transporte Privado'
  },
  1578: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  2060: {
    categories: ['Servicios Logísticos y Transporte', 'Choferes, Taxis y Transporte Privado'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'choferes-taxis-y-transporte-privado'],
    category: 'Choferes, Taxis y Transporte Privado'
  },
  2342: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  2362: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  2783: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  2822: {
    categories: ['Servicios Logísticos y Transporte', 'Choferes, Taxis y Transporte Privado'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'choferes-taxis-y-transporte-privado'],
    category: 'Choferes, Taxis y Transporte Privado'
  },
  2860: {
    categories: ['Servicios Logísticos y Transporte', 'Mandaditos y Entregas a Domicilio'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'mandaditos-y-entregas-a-domicilio'],
    category: 'Mandaditos y Entregas a Domicilio'
  },
  3227: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  3274: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  3283: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  3284: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  3543: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },
  3902: {
    categories: ['Servicios Logísticos y Transporte', 'Fletes, Mudanzas y Grúas'],
    categorySlugs: ['servicios-logisticos-y-transporte', 'fletes-mudanzas-y-gruas'],
    category: 'Fletes, Mudanzas y Grúas'
  },

  // AUTOMOTRIZ REAL (Remove incorrect categories, keep only real auto businesses)
  1585: {
    categories: ['Automotriz y Motocicletas', 'Talleres Mecánicos y Eléctricos (Autos y Motos)'],
    categorySlugs: ['automotriz-y-motocicletas', 'talleres-mecanicos-y-electricos-autos-y-motos'],
    category: 'Talleres Mecánicos y Eléctricos (Autos y Motos)'
  },
  2772: {
    categories: ['Automotriz y Motocicletas', 'Talleres Mecánicos y Eléctricos (Autos y Motos)'],
    categorySlugs: ['automotriz-y-motocicletas', 'talleres-mecanicos-y-electricos-autos-y-motos'],
    category: 'Talleres Mecánicos y Eléctricos (Autos y Motos)'
  },
  3351: {
    categories: ['Automotriz y Motocicletas', 'Agencias, Lotes de Autos y Autolavados'],
    categorySlugs: ['automotriz-y-motocicletas', 'agencias-lotes-de-autos-y-autolavados'],
    category: 'Agencias, Lotes de Autos y Autolavados'
  },
  3922: {
    categories: ['Automotriz y Motocicletas', 'Talleres Mecánicos y Eléctricos (Autos y Motos)'],
    categorySlugs: ['automotriz-y-motocicletas', 'talleres-mecanicos-y-electricos-autos-y-motos'],
    category: 'Talleres Mecánicos y Eléctricos (Autos y Motos)'
  },

  // BUSINESSES ERRONEOUSLY PUT IN AUTOMOTIVE OR OTHER WRONG CATEGORIES:
  1257: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Venta y Reparación de Celulares y Cómputo'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'venta-y-reparacion-de-celulares-y-computo'],
    category: 'Venta y Reparación de Celulares y Cómputo'
  },
  1342: {
    categories: ['Sector Industrial, Petrolero y Construcción', 'Servicios de Ingeniería, Arquitectura y Talleres de Torno'],
    categorySlugs: ['sector-industrial-petrolero-y-construccion', 'servicios-de-ingenieria-arquitectura-y-talleres-de-torno'],
    category: 'Servicios de Ingeniería, Arquitectura y Talleres de Torno'
  },
  1483: {
    categories: ['Cuidado y Belleza Personal', 'Cosméticos, Perfumería y Joyería'],
    categorySlugs: ['cuidado-y-belleza-personal', 'cosmeticos-perfumeria-y-joyeria'],
    category: 'Cosméticos, Perfumería y Joyería'
  },
  1634: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Imprentas, Publicidad y Rotulación'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'imprentas-publicidad-y-rotulacion'],
    category: 'Imprentas, Publicidad y Rotulación'
  },
  1701: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Regalos, Florerías y Novedades'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'regalos-florerias-y-novedades'],
    category: 'Regalos, Florerías y Novedades'
  },
  2023: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Regalos, Florerías y Novedades'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'regalos-florerias-y-novedades'],
    category: 'Regalos, Florerías y Novedades'
  },
  2070: {
    categories: ['Alimentos y Bebidas', 'Antojitos y Comida Rápida', 'Restaurantes y Cocinas Económicas'],
    categorySlugs: ['alimentos-y-bebidas', 'antojitos-y-comida-rapida', 'restaurantes-y-cocinas-economicas'],
    category: 'Restaurantes y Cocinas Económicas'
  },
  2152: {
    categories: ['Servicios Profesionales, Legales y Financieros', 'Consultorías, Notarías y Oficinas'],
    categorySlugs: ['servicios-profesionales-legales-y-financieros', 'consultorias-notarias-y-oficinas'],
    category: 'Consultorías, Notarías y Oficinas'
  },
  2165: {
    categories: ['Sector Industrial, Petrolero y Construcción', 'Servicios de Ingeniería, Arquitectura y Talleres de Torno'],
    categorySlugs: ['sector-industrial-petrolero-y-construccion', 'servicios-de-ingenieria-arquitectura-y-talleres-de-torno'],
    category: 'Servicios de Ingeniería, Arquitectura y Talleres de Torno'
  },
  2222: {
    categories: ['Alimentos y Bebidas', 'Antojitos y Comida Rápida', 'Restaurantes y Cocinas Económicas'],
    categorySlugs: ['alimentos-y-bebidas', 'antojitos-y-comida-rapida', 'restaurantes-y-cocinas-economicas'],
    category: 'Restaurantes y Cocinas Económicas'
  },
  2239: {
    categories: ['Alimentos y Bebidas', 'Antojitos y Comida Rápida', 'Restaurantes y Cocinas Económicas'],
    categorySlugs: ['alimentos-y-bebidas', 'antojitos-y-comida-rapida', 'restaurantes-y-cocinas-economicas'],
    category: 'Restaurantes y Cocinas Económicas'
  },
  2354: {
    categories: ['Renta de Inmuebles, Espacios y Mascotas', 'Palapas, Albercas y Lugares para Fiestas'],
    categorySlugs: ['renta-de-inmuebles-espacios-y-mascotas', 'palapas-albercas-y-lugares-para-fiestas'],
    category: 'Palapas, Albercas y Lugares para Fiestas'
  },
  2440: {
    categories: ['Tecnología, Imprentas y Comercio al Menudeo', 'Regalos, Florerías y Novedades'],
    categorySlugs: ['tecnologia-imprentas-y-comercio-al-menudeo', 'regalos-florerias-y-novedades'],
    category: 'Regalos, Florerías y Novedades'
  },
  2446: {
    categories: ['Salud, Bienestar y Educación', 'Psicología, Desarrollo Personal y Escuelas'],
    categorySlugs: ['salud-bienestar-y-educacion', 'psicologia-desarrollo-personal-y-escuelas'],
    category: 'Psicología, Desarrollo Personal y Escuelas'
  },
  2649: {
    categories: ['Alimentos y Bebidas', 'Cafeterías, Jugos y Postres'],
    categorySlugs: ['alimentos-y-bebidas', 'cafeterias-jugos-y-postres'],
    category: 'Cafeterías, Jugos y Postres'
  },
  2764: {
    categories: ['Servicios del Hogar y Oficios', 'Aluminio, Vidrios y Cerrajería'],
    categorySlugs: ['servicios-del-hogar-y-oficios', 'aluminio-vidrios-y-cerrajeria'],
    category: 'Aluminio, Vidrios y Cerrajería'
  },
  3225: {
    categories: ['Alimentos y Bebidas', 'Antojitos y Comida Rápida', 'Restaurantes y Cocinas Económicas'],
    categorySlugs: ['alimentos-y-bebidas', 'antojitos-y-comida-rapida', 'restaurantes-y-cocinas-economicas'],
    category: 'Antojitos y Comida Rápida'
  },
  3250: {
    categories: ['Servicios del Hogar y Oficios', 'Plomería y Servicios Eléctricos'],
    categorySlugs: ['servicios-del-hogar-y-oficios', 'plomeria-y-servicios-electricos'],
    category: 'Plomería y Servicios Eléctricos'
  },
  3534: {
    categories: ['Renta de Inmuebles, Espacios y Mascotas', 'Clínicas Veterinarias y Servicios para Mascotas'],
    categorySlugs: ['renta-de-inmuebles-espacios-y-mascotas', 'clinicas-veterinarias-y-servicios-para-mascotas'],
    category: 'Clínicas Veterinarias y Servicios para Mascotas'
  },
  3894: {
    categories: ['Salud, Bienestar y Educación', 'Educación, Cursos y Escuelas'],
    categorySlugs: ['salud-bienestar-y-educacion', 'educacion-cursos-y-escuelas'],
    category: 'Educación, Cursos y Escuelas'
  },
  3900: {
    categories: ['Sector Industrial, Petrolero y Construcción', 'Gas y Combustibles'],
    categorySlugs: ['sector-industrial-petrolero-y-construccion', 'gas-y-combustibles'],
    category: 'Gas y Combustibles'
  }
};

async function main() {
  console.log('Connecting to Hostinger MariaDB...');
  const connected = await initMariaDb();
  if (!connected) {
    console.error('Could not connect to MariaDB');
    process.exit(1);
  }

  const dbList = await dbLoadAllBusinesses();
  console.log(`Loaded ${dbList.length} businesses from Hostinger MariaDB.`);

  let updatedCount = 0;
  for (const b of dbList) {
    const fix = DEFINITIVE_FIXES[Number(b.id)];
    if (fix) {
      console.log(`[${b.id}] Updating "${b.name}" -> ${fix.categories.join(' > ')}`);
      b.categories = fix.categories;
      b.categorySlugs = fix.categorySlugs;
      b.category = fix.category;
      b.updatedAt = new Date().toISOString();
      const saved = await dbSaveBusiness(b);
      if (saved) updatedCount++;
      else console.warn(`Failed to save [${b.id}] to MariaDB`);
    }
  }
  console.log(`Updated ${updatedCount} businesses in Hostinger MariaDB.`);

  // Also update local businesses_seed.json
  const seedPath = path.resolve('./src/data/businesses_seed.json');
  if (fs.existsSync(seedPath)) {
    const seed = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
    for (const b of seed) {
      const fix = DEFINITIVE_FIXES[Number(b.id)];
      if (fix) {
        b.categories = fix.categories;
        b.categorySlugs = fix.categorySlugs;
        b.category = fix.category;
        b.updatedAt = new Date().toISOString();
      }
    }
    fs.writeFileSync(seedPath, JSON.stringify(seed, null, 2));
    console.log('Synchronized businesses_seed.json with definitive fixes.');
  }

  // Recalculate categories_seed.json counts
  const catPath = path.resolve('./src/data/categories_seed.json');
  if (fs.existsSync(catPath)) {
    const cats = JSON.parse(fs.readFileSync(catPath, 'utf8'));
    const finalBiz = JSON.parse(fs.readFileSync(seedPath, 'utf8'));
    for (const c of cats) {
      const slug = c.slug;
      const name = c.name;
      let count = 0;
      for (const b of finalBiz) {
        const hasSlug = b.categorySlugs && b.categorySlugs.includes(slug);
        const hasName = b.categories && b.categories.includes(name);
        if (hasSlug || hasName) count++;
      }
      c.count = count;
    }
    fs.writeFileSync(catPath, JSON.stringify(cats, null, 2));
    console.log('Recalculated and saved categories_seed.json counts.');
  }

  console.log('All changes applied cleanly.');
  process.exit(0);
}

main().catch(e => {
  console.error('Error:', e);
  process.exit(1);
});
