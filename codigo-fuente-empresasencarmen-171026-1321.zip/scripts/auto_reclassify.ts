import fs from 'fs';
import path from 'path';
import { initMariaDb, dbLoadAllBusinesses, dbSaveBusiness } from '../src/db/mariadb';

// Helper to determine category based on keywords
function getCategory(name, desc) {
    const text = (name + ' ' + desc).toLowerCase();
    
    // Industrial
    if (text.includes('industrial') || text.includes('torno') || text.includes('seguridad') || text.includes('epp') || text.includes('petrolero') || text.includes('construcción')) {
        return { cat: 'Sector Industrial, Petrolero y Construcción', sub: 'Seguridad Industrial y Equipo de Protección (EPP)', slug: 'seguridad-industrial-y-equipo-de-proteccion-epp' };
    }
    // Food
    if (text.includes('carnicería') || text.includes('res') || text.includes('pollo') || text.includes('alimentos') || text.includes('comida') || text.includes('restaurante') || text.includes('tacos')) {
        return { cat: 'Alimentos y Bebidas', sub: 'Restaurantes y Cocinas Económicas', slug: 'restaurantes-y-cocinas-economicas' };
    }
    // Beauty
    if (text.includes('uñas') || text.includes('pestañas') || text.includes('belleza') || text.includes('spa') || text.includes('maquillaje') || text.includes('cosméticos')) {
        return { cat: 'Cuidado y Belleza Personal', sub: 'Aplicación de Uñas y Pestañas', slug: 'aplicacion-de-unas-y-pestanas' };
    }
    // Auto/Moto
    if (text.includes('auto') || text.includes('moto') || text.includes('taller') || text.includes('mecánico')) {
        return { cat: 'Automotriz y Motocicletas', sub: 'Talleres Mecánicos y Eléctricos (Autos y Motos)', slug: 'talleres-mecanicos-y-electricos-autos-y-motos' };
    }
    // Logistics
    if (text.includes('flete') || text.includes('mudanza') || text.includes('logística') || text.includes('transporte') || text.includes('taxi')) {
        return { cat: 'Servicios Logísticos y Transporte', sub: 'Servicios Logísticos y Transporte', slug: 'servicios-logisticos-y-transporte' };
    }

    return null;
}

async function run() {
  console.log('Connecting to Hostinger MariaDB...');
  const connected = await initMariaDb();
  if (!connected) {
    console.error('Failed to connect to MariaDB.');
    process.exit(1);
  }

  const dbList = await dbLoadAllBusinesses();
  console.log(`Loaded ${dbList.length} businesses from Hostinger MariaDB.`);

  let updatedCount = 0;
  for (const b of dbList) {
    const newCat = getCategory(b.name, b.description);
    if (newCat) {
        if (!b.categories.includes(newCat.cat) || !b.categorySlugs.includes(newCat.slug)) {
            console.log(`Updating [${b.id}] "${b.name}" to ${newCat.cat} > ${newCat.sub}`);
            b.categories = [newCat.cat, newCat.sub];
            b.categorySlugs = [newCat.slug.split('-')[0], newCat.slug]; // Simplified slug hierarchy
            b.category = newCat.sub;
            b.updatedAt = new Date().toISOString();
            await dbSaveBusiness(b);
            updatedCount++;
        }
    }
  }

  console.log(`Successfully updated ${updatedCount} businesses in Hostinger MariaDB.`);
  process.exit(0);
}

run().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});
